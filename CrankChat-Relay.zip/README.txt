CRANK CHAT RELAY
================

Crank Chat is an experiment: texting from a Playdate. The Playdate cannot log into Telegram or send a
phone text by itself, so this small program runs on your computer and passes messages back and forth.

    Playdate  <-- your Wi-Fi -->  relay.py on your computer  <-->  Telegram / the Mac's Messages app

What you need:
  - A Mac (or a Linux computer) and your Playdate on the SAME Wi-Fi network.
  - The Crank Chat app on your Playdate (CrankChat-Playdate.zip).
  - Phone texts only work on a Mac. Telegram works on both.
  - Keep the computer awake and the relay running while you chat.

You will type a few lines into Terminal. Type them exactly, including spaces, and press Return after each.


PART 1: START THE RELAY (Mac, about 5 minutes)
----------------------------------------------

1. Unzip CrankChat-Relay.zip (double-click it). You get a folder called CrankChat-Relay.

2. Open Terminal: Finder > Applications > Utilities > Terminal.

3. Type   python3   then a SPACE (do not press Return yet).
   Drag the file relay.py from the CrankChat-Relay folder onto the Terminal window.
   Its full location appears after "python3 ". Now press Return.

   The line looks something like this:
       python3 /Users/you/Downloads/CrankChat-Relay/relay.py

4. If your Mac asks to install "command line developer tools", click Install, wait for it to finish,
   then do step 3 again. (That is Apple's free package that includes python3.)

5. The relay prints something like:

       In the Playdate app, enter:
          address  192.168.1.20:8100
          key      Ab3dEf9h

   Write both down. The key is case-sensitive (capital and small letters matter).

6. Leave this Terminal window OPEN. Closing it, or pressing Ctrl-C, stops the relay.
   While the Playdate is connected you will see lines like
       "GET /chats.txt?... 200"
   scrolling past about once a second. That is normal: it is the Playdate asking "anything new?".


PART 2: CONNECT THE PLAYDATE
----------------------------

1. Put CrankChat.pdx on your Playdate (Settings > System > Reboot to Data Disk, plug it into your
   computer, copy CrankChat.pdx into the Games folder, eject).

2. Open Crank Chat. It shows a "Welcome!" screen. Press A.

3. Type the ADDRESS with the crank keyboard (for example 192.168.1.20:8100), then choose OK.
   Then type the KEY, then choose OK.

4. A chat with "Braq-bot", a demo friend, appears. Send it a message: it answers.
   That proves the Playdate and the relay are talking. Telegram and phone texts are next.

To change the address or key later: open the Playdate's menu while in Crank Chat and choose "set up".


PART 3: TELEGRAM (optional, about 10 minutes)
---------------------------------------------

You make your OWN Telegram bot. Your friends message the bot, and those messages show up on your Playdate.

1. In Telegram, open a chat with @BotFather (the official bot for making bots, with a blue check mark).
   Send   /newbot   and answer its two questions (a display name, then a username ending in "bot").
   It replies with a TOKEN that looks like  1234567890:AAH...  Copy it.
   Treat the token like a password: anyone who has it controls your bot.

2. Find your own Telegram user id (a number, not your @username):
   message a bot such as @userinfobot and it replies with your id.
   Do the same for each friend you want to let in (they can message @userinfobot and send you the number).

3. Save both in Terminal. If the relay is running, press Ctrl-C first. Then type these lines, putting
   YOUR token and YOUR id between the quotes:

       mkdir -p ~/.crank_chat
       echo "1234567890:AAH-your-token-here" > ~/.crank_chat/telegram_token.txt
       echo "123456789" > ~/.crank_chat/telegram_allow.txt

   For several people, put their ids on one line separated by spaces, e.g.  echo "111 222 333" > ...
   Only these people can reach you. Anyone else who finds the bot is ignored.

4. Start the relay again (Part 1, step 3; press the Up arrow key in Terminal to bring the line back).
   It now says:   Telegram bridge ON (only 1 allowed people)

5. In Telegram, open your bot and send it a message. It appears on your Playdate. Replies from the
   Playdate arrive in Telegram.


PART 4: PHONE TEXTS (Mac only, optional)
----------------------------------------

The relay can send and read texts through your Mac's Messages app, for people you add by number.

1. Messages must be signed in on the Mac. For texts to non-iPhone numbers (green bubbles), also turn on
   iPhone > Settings > Apps > Messages > Text Message Forwarding > your Mac.

2. Give Terminal "Full Disk Access" so the relay can read incoming texts:
   System Settings > Privacy & Security > Full Disk Access > turn on Terminal
   (if it is not in the list, click + and choose Applications > Utilities > Terminal).
   Then press Ctrl-C in Terminal and start the relay again.

3. On the Playdate, in the chat list, choose "+ Add a person": type a name, then the phone number with
   its area code.

4. The first time you send a text, macOS asks whether Terminal may control Messages. Click OK.

The relay only reads messages from the numbers you add, and only ones that arrive after you add the
first person. Nobody else's messages are read.


IF SOMETHING GOES WRONG
-----------------------

"zsh: no such file or directory"     A space is missing (e.g. "cd/Users..." must be "cd /Users...").
"zsh: permission denied"             You ran relay.py without "python3 " in front. Use Part 1, step 3.
"command not found: python3"         Check the spelling, or do Part 1, step 4.
"Address already in use"             A relay is already running (maybe in another Terminal window).
                                     Use that one, or stop it: close that window, or type  pkill -f relay.py
"Messages: cannot read the Messages database"
                                     Terminal needs Full Disk Access (Part 4, step 2). Telegram still works.
The Playdate says "no answer"        Wrong address, the relay is not running, or the Playdate and the
                                     computer are on different Wi-Fi networks. Some school, office and
                                     hotel networks block devices from reaching each other; a home
                                     network or a phone hotspot usually works.
The Playdate says "wrong key"        Re-type the key (menu > set up). Capital and small letters matter.
It worked yesterday, not today       Your computer's address can change when you change networks.
                                     Start the relay and read the address again.

Where things are kept: the folder ~/.crank_chat in your home folder (hidden; in Finder press
Cmd+Shift+G and type ~/.crank_chat). key.txt holds the key. Delete it and restart the relay to make a
new key (then type the new one on the Playdate).


GOOD TO KNOW
------------

- Messages are not end-to-end encrypted, and the key travels over your Wi-Fi unencrypted. Use it for
  casual chat on a network you trust.
- Emoji and non-Latin letters show as "?" on the Playdate.
- Linux: run it the same way (python3 relay.py). To start it automatically, read the top of
  crank-chat-relay.service. Phone texts are Mac only.
- Windows has not been tested.

Made by Boraq Abdulmajeed, with Claude Code. Not made or endorsed by Panic or Telegram.
