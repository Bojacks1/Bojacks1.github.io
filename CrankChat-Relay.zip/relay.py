#!/usr/bin/env python3
"""relay.py: the go-between for the Playdate texting app (Crank Chat).

The Playdate talks ONLY to this small server, in plain text. The server holds the conversations and talks to the real
messaging service (Telegram today). That keeps secrets (the Telegram bot token) OFF the Playdate, where anyone could unpack
the game file and read them, and it keeps the Playdate's job small and fast.

    python3 relay.py                        # demo mode: a bot called "Braq-bot" answers you, no accounts needed
    TELEGRAM_BOT_TOKEN=123:abc python3 relay.py --telegram        # also bridge a Telegram bot (see ../docs/PLAN.md)

It prints the address and the key to type into the Playdate app. Everything is stored in ~/.crank_chat/.

WHAT IT SERVES (every request needs ?k=<key>, except /ping):
  /ping                                      "ok" (to test the connection)
  /chats.txt                                 one line per conversation: id <TAB> name <TAB> unread <TAB> last message
  /msgs.txt?chat=<id>&after=<n>              messages numbered above n: n <TAB> me|them <TAB> HH:MM <TAB> text
  /read?chat=<id>                            marks a conversation read
  /send   (POST chat=<id>&text=<text>)       sends a message (a GET with the same parameters also works, for testing)

PRIVACY AND SAFETY: this is for your own home network (and, later, a tunnel you control). Do not leave it open on the
internet without the key, and do not share the key. Messages are stored in plain text on this computer.
"""
import argparse
import hmac
import json
import os
import secrets
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

DATA_DIR = os.path.expanduser("~/.crank_chat")
MAX_TEXT = 400              # characters per message (the Playdate screen is small)
KEEP_MESSAGES = 300         # messages remembered per conversation

# What the Playdate's system font can draw: Latin letters and common punctuation. Anything else (emoji, other scripts)
# would show as an empty box, so it is replaced. These few typographic characters are turned into plain ones first.
PLAIN = {"‘": "'", "’": "'", "“": '"', "”": '"', "–": "-", "—": "-", "…": "...", " ": " "}


def playdate_safe(text):
    """Turns a message into text the Playdate can show: one line per message, tidy punctuation, and a single '?' for
    each run of characters its font cannot draw (emoji, for example). Cut to MAX_TEXT characters."""
    out, in_unknown = [], False
    for ch in text.replace("\r", "").replace("\n", " ").replace("\t", " "):
        ch = PLAIN.get(ch, ch)
        ok = all(32 <= ord(c) < 0x250 for c in ch)
        if ok:
            out.append(ch)
            in_unknown = False
        elif not in_unknown:
            out.append("?")
            in_unknown = True
    return "".join(out).strip()[:MAX_TEXT]


# ---------------------------------------------------------------- the conversations

class Store:
    """All conversations, kept in memory and saved to a JSON file after every change."""

    def __init__(self, path=None):
        self.path = path
        self.lock = threading.RLock()
        self.cond = threading.Condition(self.lock)   # lets a request wait until something changes ("long polling")
        self.version = 1                              # goes up whenever any conversation changes: the chat list uses it to know it is out of date
        self.chats = {}                    # id -> {"name", "msgs": [{n, who, t, text}], "unread", "updated", "next"}
        if path and os.path.exists(path):
            try:
                with open(path) as f:
                    self.chats = json.load(f)
            except (OSError, ValueError):
                self.chats = {}

    def _save(self):
        if not self.path:
            return
        tmp = self.path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(self.chats, f)
        os.replace(tmp, self.path)

    def ensure(self, chat_id, name):
        """Makes the conversation exist (and refreshes its name)."""
        with self.lock:
            chat = self.chats.setdefault(chat_id, {"name": name or chat_id, "msgs": [], "unread": 0, "updated": time.time(), "next": 1})   # (a new chat starts at the TOP of the list)
            if name:                                 # only a real name replaces the old one (a message YOU send has no name to give)
                chat["name"] = name
            return chat

    def add(self, chat_id, who, text, name=None, when=None):
        """Adds a message ('me' or 'them') and returns its number. A message from them counts as unread."""
        with self.lock:
            chat = self.ensure(chat_id, name)
            n = chat["next"]
            chat["next"] = n + 1
            stamp = when if when is not None else time.time()
            chat["msgs"].append({"n": n, "who": who, "t": stamp, "text": playdate_safe(text)})
            del chat["msgs"][:-KEEP_MESSAGES]
            chat["updated"] = stamp
            if who == "them":
                chat["unread"] += 1
            self._save()
            self._changed()
            return n

    def _changed(self):
        """Something changed: bump the version and wake everyone who is waiting for news."""
        with self.cond:
            self.version += 1
            self.cond.notify_all()

    def mark_read(self, chat_id):
        with self.lock:
            if chat_id in self.chats and self.chats[chat_id]["unread"] != 0:
                self.chats[chat_id]["unread"] = 0
                self._save()
                self._changed()

    def wait_chats(self, version, timeout):
        """The chat list, as (version, text). If `version` is still the current one, WAIT (up to `timeout` seconds) until something changes:
        the Playdate asks "anything new since version N?" and gets the answer the moment there is one, instead of asking again and again."""
        with self.cond:
            deadline = time.time() + timeout
            while self.version == version and time.time() < deadline:
                self.cond.wait(max(0.0, deadline - time.time()))
            return self.version, self.chat_lines()

    def wait_msgs(self, chat_id, after, timeout):
        """Messages numbered above `after`; if there are none yet, WAIT (up to `timeout` seconds) for one to arrive."""
        with self.cond:
            deadline = time.time() + timeout
            while True:
                lines = self.msg_lines(chat_id, after)
                if lines or time.time() >= deadline:
                    return lines
                self.cond.wait(max(0.0, deadline - time.time()))

    def chat_lines(self):
        """The /chats.txt text: newest conversation first."""
        with self.lock:
            rows = sorted(self.chats.items(), key=lambda kv: -kv[1]["updated"])
            lines = []
            for cid, c in rows:
                last = c["msgs"][-1]["text"][:40] if c["msgs"] else ""
                lines.append("%s\t%s\t%d\t%s" % (cid, c["name"].replace("\t", " "), c["unread"], last))
            return "\n".join(lines) + ("\n" if lines else "")

    def msg_lines(self, chat_id, after):
        """The /msgs.txt text: messages numbered above `after`."""
        with self.lock:
            chat = self.chats.get(chat_id)
            if not chat:
                return ""
            lines = ["%d\t%s\t%s\t%s" % (m["n"], m["who"], time.strftime("%H:%M", time.localtime(m["t"])), m["text"])
                     for m in chat["msgs"] if m["n"] > after]
            return "\n".join(lines) + ("\n" if lines else "")


# ---------------------------------------------------------------- the backends

class DemoBackend:
    """A fake friend, so the whole app can be tried with no accounts: it greets you and echoes what you send."""

    def __init__(self, store):
        self.store = store
        store.ensure("demo", "Braq-bot")
        if not store.chats["demo"]["msgs"]:
            store.add("demo", "them", "Hi! I am a test friend. Send me anything and I will answer.", "Braq-bot")

    def owns(self, chat_id):
        return chat_id == "demo"

    def send(self, chat_id, text):
        """Replies after a second, like a person would."""
        reply = {"hi": "Hello!", "hello": "Hello!", "how are you": "Doing great, thanks."}.get(text.lower().strip("?!. "), "You said: " + text)
        threading.Timer(1.0, lambda: self.store.add("demo", "them", reply, "Braq-bot")).start()
        return True


class TelegramBackend:
    """Bridges a Telegram BOT. People message the bot (or add it to a group); their messages appear as conversations here, and
    what you send goes back through the bot. (A bot cannot start a conversation: the other person must message it first.)

    `api` is a function (method, params) -> dict; it is a parameter so the tests can fake Telegram.
    """

    def __init__(self, store, token, allowed=None, api=None):
        self.store = store
        self.token = token
        self.allowed = set(allowed or [])          # Telegram user ids allowed to talk to this relay (empty = anyone who finds the bot)
        self.api = api or self._http_api
        self.offset = 0
        self.stop = False

    def _http_api(self, method, params):
        """Calls the Telegram Bot API over HTTPS (JSON in, JSON out)."""
        url = "https://api.telegram.org/bot%s/%s" % (self.token, method)
        req = urllib.request.Request(url, json.dumps(params).encode(), {"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=40) as r:
            return json.load(r)

    def owns(self, chat_id):
        return chat_id.startswith("tg")

    def send(self, chat_id, text):
        result = self.api("sendMessage", {"chat_id": int(chat_id[2:]), "text": text})
        return bool(result.get("ok"))

    def poll_once(self):
        """Asks Telegram for new messages (it waits up to 25 seconds if there are none) and stores them. Returns how many."""
        result = self.api("getUpdates", {"offset": self.offset, "timeout": 25, "allowed_updates": ["message"]})
        count = 0
        for update in result.get("result", []):
            self.offset = max(self.offset, update["update_id"] + 1)
            msg = update.get("message")
            if not msg or "text" not in msg:
                continue
            sender = msg.get("from", {})
            if self.allowed and sender.get("id") not in self.allowed:
                continue
            chat = msg["chat"]
            name = chat.get("title") or " ".join(x for x in (sender.get("first_name"), sender.get("last_name")) if x) or str(chat["id"])
            self.store.add("tg%d" % chat["id"], "them", msg["text"], name)
            count += 1
        return count

    def run(self):
        """The background loop: poll forever, backing off a little after errors."""
        while not self.stop:
            try:
                self.poll_once()
            except Exception as e:                       # network trouble: wait and try again
                print("telegram:", e, file=sys.stderr)
                time.sleep(5)



# ---------------------------------------------------------------- the Messages backend (texts to real phone numbers)

def normalize_number(text):
    """Turns what a person typed ("(734) 555-0100", "734-555-0100", "+1 734 555 0100") into "+17345550100", or None if it is too short.
    A 10-digit number is taken as a US number (+1), because that is where this was made; a number that starts with + keeps its country code."""
    digits = "".join(c for c in text if c.isdigit())
    if len(digits) < 7:
        return None
    if text.strip().startswith("+"):
        return "+" + digits
    if len(digits) == 10:
        return "+1" + digits
    if len(digits) == 11 and digits.startswith("1"):
        return "+" + digits
    return "+" + digits


def text_from_attributed_body(blob):
    """Newer macOS often stores a message's words not in the plain `text` column but inside `attributedBody`, a small binary "typedstream".
    The words sit right after the marker `NSString` + a few bytes + a "+" (0x2b) and a length (one byte, or 0x81 and two bytes, little-endian).
    This finds them without needing a full decoder. Returns "" if it cannot."""
    if not blob:
        return ""
    i = blob.find(b"NSString")
    if i < 0:
        return ""
    j = blob.find(b"+", i)
    if j < 0 or j + 2 > len(blob):
        return ""
    length = blob[j + 1]
    start = j + 2
    if length == 0x81:                                   # a longer text: the next two bytes hold its length
        length = int.from_bytes(blob[j + 2:j + 4], "little")
        start = j + 4
    return blob[start:start + length].decode("utf-8", "replace")


def send_via_messages_app(number, text):
    """Sends a text through the Mac's Messages app (an iMessage if the person has one, otherwise a text message through your iPhone, which needs
    "Text Message Forwarding" switched on for this Mac). The number and the words are passed as arguments, never pasted into the script, so
    quotes or odd characters in a message cannot break it or run as code. Returns True if AppleScript raised no error.
    (The first send makes macOS ask whether to allow controlling Messages: say yes.)"""
    script = """on run argv
    set theNumber to item 1 of argv
    set theText to item 2 of argv
    tell application "Messages"
        try
            set svc to 1st service whose service type = iMessage
            send theText to buddy theNumber of svc
        on error
            set svc to 1st service whose service type = SMS
            send theText to buddy theNumber of svc
        end try
    end tell
end run"""
    try:
        r = subprocess.run(["osascript", "-e", script, number, text], capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.SubprocessError):
        return False
    if r.returncode != 0:
        sys.stderr.write("Messages could not send: %s\n" % r.stderr.strip()[:200])
    return r.returncode == 0


def read_new_messages(db_path, after_rowid, numbers):
    """Reads texts that arrived after row `after_rowid` FROM the given phone numbers, and nothing else: the query itself only selects rows whose
    sender matches one of `numbers` (compared by the last 10 digits), so other people's messages are never even read into memory.
    Returns (list of (rowid, number_digits, text), the highest row number in the whole table). The Messages database is opened read-only."""
    import sqlite3
    con = sqlite3.connect("file:%s?mode=ro" % db_path, uri=True, timeout=5)
    try:
        newest = con.execute("SELECT COALESCE(MAX(ROWID), 0) FROM message").fetchone()[0]
        if not numbers or newest <= after_rowid:
            return [], newest
        tails = [("".join(c for c in n if c.isdigit()))[-10:] for n in numbers]
        where = " OR ".join("h.id LIKE ?" for _ in tails)
        rows = con.execute(
            "SELECT m.ROWID, h.id, m.text, m.attributedBody FROM message m JOIN handle h ON m.handle_id = h.ROWID "
            "WHERE m.ROWID > ? AND m.is_from_me = 0 AND (%s) ORDER BY m.ROWID" % where,
            [after_rowid] + ["%" + t for t in tails]).fetchall()
    finally:
        con.close()
    out = []
    for rowid, handle, text, blob in rows:
        words = text if text else text_from_attributed_body(blob)
        if words and words.strip():
            out.append((rowid, "".join(c for c in handle if c.isdigit()), words.strip()))
    return out, newest


class MessagesBackend:
    """Texts to real phone numbers, through the Mac's Messages app.

    You add a person (a name and a number); they become a conversation named "sms<digits>". Sending goes out through Messages. Replies are
    found by READING the Messages database for new texts from the numbers you added: only those numbers, never anyone else's messages, and only
    texts that arrive AFTER the person was added (old history is never imported). Reading the database needs "Full Disk Access" for the program that
    runs the relay (System Settings > Privacy & Security > Full Disk Access: Terminal, or the app you start it from).

    `send_fn` and `db_path` are parameters so the tests can fake Messages.
    """

    def __init__(self, store, folder, send_fn=None, db_path=None):
        self.store = store
        self.folder = folder
        self.send_fn = send_fn or send_via_messages_app
        self.db_path = db_path or os.path.expanduser("~/Library/Messages/chat.db")
        self.contacts_path = os.path.join(folder, "contacts.json")
        self.state_path = os.path.join(folder, "messages_state.json")
        self.contacts = {}                  # chat id -> {"name", "number"}
        self.last_rowid = None              # the newest Messages row already looked at
        self.warned = False
        self.stop = False
        try:
            with open(self.contacts_path) as f:
                self.contacts = json.load(f)
        except (OSError, ValueError):
            pass
        try:
            with open(self.state_path) as f:
                self.last_rowid = json.load(f).get("last_rowid")
        except (OSError, ValueError):
            pass
        for cid, c in self.contacts.items():
            store.ensure(cid, c["name"])

    def _save(self):
        os.makedirs(self.folder, exist_ok=True)
        for path, data in ((self.contacts_path, self.contacts), (self.state_path, {"last_rowid": self.last_rowid})):
            tmp = path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(data, f)
            os.chmod(tmp, 0o600)
            os.replace(tmp, path)

    def owns(self, chat_id):
        return chat_id.startswith("sms")

    def add_contact(self, name, number_text):
        """Adds a person. Returns their chat id, or None if the number is not usable."""
        number = normalize_number(number_text)
        if number is None:
            return None
        cid = "sms" + number.lstrip("+")
        name = (name or "").strip() or number
        self.contacts[cid] = {"name": playdate_safe(name)[:30], "number": number}
        self.store.ensure(cid, self.contacts[cid]["name"])
        if self.last_rowid is None:                      # first contact ever: start from NOW, so old messages are never imported
            self.last_rowid = self._newest_rowid()
        self._save()
        self.store._changed()
        return cid

    def remove_contact(self, chat_id):
        if chat_id in self.contacts:
            del self.contacts[chat_id]
            self._save()

    def send(self, chat_id, text):
        contact = self.contacts.get(chat_id)
        return bool(contact) and bool(self.send_fn(contact["number"], text))

    def _newest_rowid(self):
        try:
            return read_new_messages(self.db_path, 10 ** 15, [])[1] if os.path.exists(self.db_path) else 0
        except Exception:
            return None

    def poll_once(self):
        """Looks for new texts from the added numbers and stores them. Returns how many arrived."""
        if not self.contacts:
            return 0
        if self.last_rowid is None:
            self.last_rowid = self._newest_rowid()
            if self.last_rowid is None:
                return 0
        try:
            found, newest = read_new_messages(self.db_path, self.last_rowid, [c["number"] for c in self.contacts.values()])
        except Exception as e:                           # most often: no permission to read the Messages database yet
            if not self.warned:
                self.warned = True
                sys.stderr.write("Messages: cannot read the Messages database (%s). Give the program that runs relay.py Full Disk Access: "
                                 "System Settings > Privacy & Security > Full Disk Access.\n" % e)
            return 0
        count = 0
        for rowid, digits, words in found:
            for cid, c in self.contacts.items():
                if "".join(ch for ch in c["number"] if ch.isdigit())[-10:] == digits[-10:]:
                    self.store.add(cid, "them", words, c["name"])
                    count += 1
        if newest != self.last_rowid:
            self.last_rowid = newest
            self._save()
        return count

    def run(self):
        """The background loop: look for new texts every couple of seconds."""
        while not self.stop:
            try:
                self.poll_once()
            except Exception as e:
                sys.stderr.write("Messages: %s\n" % e)
            time.sleep(2.0)


# ---------------------------------------------------------------- the web server

def local_address(port):
    """This computer's address on the home network, as ip:port."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return "%s:%d" % (s.getsockname()[0], port)
    except OSError:
        return "127.0.0.1:%d" % port
    finally:
        s.close()


def wait_seconds(params):
    """How long a request may wait for news, from ?wait=<seconds> (none by default, at most 25)."""
    try:
        return max(0.0, min(25.0, float(params.get("wait", "0"))))
    except ValueError:
        return 0.0


def make_handler(store, backends, key):
    """Builds the request handler for this store, backends and key."""

    def backend_for(chat_id):
        return next((b for b in backends if b.owns(chat_id)), None)

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):
            sys.stderr.write("%s  %s\n" % (time.strftime("%H:%M:%S"), fmt % args))

        def reply(self, text, status=200):
            body = text.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Connection", "close")
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass                      # the Playdate stopped waiting (it gave up or moved on): nothing to do

        def handle_request(self, params):
            """Routes one request (params = the query and, for a POST, the form body, as a dictionary of strings)."""
            path = urllib.parse.urlparse(self.path).path
            if path == "/ping":
                return self.reply("ok\n")
            if not hmac.compare_digest(params.get("k", ""), key):         # constant-time compare: no timing clues
                return self.reply("wrong key\n", 403)
            if path == "/chats.txt":
                if "ver" in params:                                   # the long-polling form: "@<version>" on the first line
                    try:
                        ver = int(params["ver"])
                    except ValueError:
                        ver = 0
                    ver_now, lines = store.wait_chats(ver, wait_seconds(params))
                    return self.reply("@%d\n%s" % (ver_now, lines))
                return self.reply(store.chat_lines())
            if path == "/msgs.txt":
                try:
                    after = int(params.get("after", "0"))
                except ValueError:
                    after = 0
                return self.reply(store.wait_msgs(params.get("chat", ""), after, wait_seconds(params)))
            if path == "/addcontact":
                messages = next((b for b in backends if hasattr(b, "add_contact")), None)
                cid = messages.add_contact(params.get("name", ""), params.get("number", "")) if messages else None
                return self.reply("ok %s\n" % cid if cid else "error: that does not look like a phone number\n", 200 if cid else 400)
            if path == "/removecontact":
                messages = next((b for b in backends if hasattr(b, "remove_contact")), None)
                if messages:
                    messages.remove_contact(params.get("chat", ""))
                return self.reply("ok\n")
            if path == "/read":
                store.mark_read(params.get("chat", ""))
                return self.reply("ok\n")
            if path == "/send":
                chat_id, text = params.get("chat", ""), playdate_safe(params.get("text", ""))
                backend = backend_for(chat_id)
                if not text or backend is None:
                    return self.reply("error: no such chat or empty message\n", 400)
                if not backend.send(chat_id, text):
                    return self.reply("error: the service refused the message\n", 502)
                store.add(chat_id, "me", text)
                return self.reply("ok\n")
            self.reply("not found\n", 404)

        def do_GET(self):
            q = urllib.parse.urlparse(self.path).query
            self.handle_request({k: v[0] for k, v in urllib.parse.parse_qs(q).items()})

        def do_POST(self):
            length = int(self.headers.get("Content-Length", "0") or 0)
            body = self.rfile.read(min(length, 4096)).decode("utf-8", "replace")
            q = urllib.parse.urlparse(self.path).query
            params = {k: v[0] for k, v in urllib.parse.parse_qs(q).items()}
            params.update({k: v[0] for k, v in urllib.parse.parse_qs(body).items()})
            self.handle_request(params)

    return Handler


def load_key():
    """The shared key: read from ~/.crank_chat/key.txt, or made the first time."""
    os.makedirs(DATA_DIR, exist_ok=True)
    path = os.path.join(DATA_DIR, "key.txt")
    if os.path.exists(path):
        return open(path).read().strip()
    key = secrets.token_urlsafe(6)
    with open(path, "w") as f:
        f.write(key + "\n")
    os.chmod(path, 0o600)
    return key


def load_telegram_settings(folder):
    """Reads the Telegram bot's settings from files in `folder` (normally ~/.crank_chat):

      telegram_token.txt   the bot's token from @BotFather (one line). Treat it like a password: anyone who has it controls the bot.
      telegram_allow.txt   optional: the numeric Telegram ids of the people allowed to talk to the bot, separated by spaces or lines.
                           With no file (or an empty one) ANYONE who finds the bot's name can message it.

    Returns (token, allowed_ids): token is None when there is no token file."""
    token, allowed = None, []
    try:
        with open(os.path.join(folder, "telegram_token.txt")) as f:
            token = f.read().strip() or None
    except OSError:
        pass
    try:
        with open(os.path.join(folder, "telegram_allow.txt")) as f:
            allowed = [int(w) for w in f.read().split() if w.lstrip("-").isdigit()]
    except OSError:
        pass
    return token, allowed


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--port", type=int, default=8100)
    ap.add_argument("--bind", default="0.0.0.0", help="the address to listen on (default: all; use 127.0.0.1 behind a tunnel on the same machine)")
    ap.add_argument("--telegram", action="store_true", help="bridge a Telegram bot (token from the TELEGRAM_BOT_TOKEN environment variable); this is automatic when ~/.crank_chat/telegram_token.txt exists")
    ap.add_argument("--no-telegram", action="store_true", help="do not start the Telegram bridge even if a token file exists")
    ap.add_argument("--allow", type=int, nargs="*", default=[], help="Telegram user ids allowed to message you (default: the ids in telegram_allow.txt, else anyone who finds the bot)")
    args = ap.parse_args()
    os.makedirs(DATA_DIR, exist_ok=True)
    store = Store(os.path.join(DATA_DIR, "store.json"))
    backends = [DemoBackend(store)]
    if sys.platform == "darwin":       # texting real phone numbers goes through the Mac's Messages app, so it exists only on a Mac
        messages = MessagesBackend(store, DATA_DIR)
        backends.append(messages)
        threading.Thread(target=messages.run, daemon=True).start()
    else:
        print("Running without Messages (phone-number texting needs a Mac). Telegram and the demo friend still work.")
    file_token, file_allowed = load_telegram_settings(DATA_DIR)
    token = os.environ.get("TELEGRAM_BOT_TOKEN") or file_token
    if token and not args.no_telegram:
        allowed = args.allow or file_allowed
        tg = TelegramBackend(store, token, allowed)
        backends.append(tg)
        threading.Thread(target=tg.run, daemon=True).start()
        print("Telegram bridge ON (%s)" % ("only %d allowed people" % len(allowed) if allowed else "ANYONE who finds the bot can message it: put the ids of the people you trust in ~/.crank_chat/telegram_allow.txt"))
    elif args.telegram:
        sys.exit("No Telegram token: put it in ~/.crank_chat/telegram_token.txt (see docs/PLAN.md).")
    key = load_key()
    print("\nIn the Playdate app, enter:\n   address  %s\n   key      %s\n" % (local_address(args.port), key))
    ThreadingHTTPServer((args.bind, args.port), make_handler(store, backends, key)).serve_forever()


if __name__ == "__main__":
    main()
