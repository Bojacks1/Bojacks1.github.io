"""Arabic text for the Playdate: letter shaping and left-to-right ordering, with no libraries.

THE PROBLEM
The Playdate draws text one character at a time, left to right, using a font where every character is a fixed picture. Arabic needs two
things that kind of drawing cannot do by itself:
  1. SHAPING. An Arabic letter has up to four shapes (alone, at the start of a word, in the middle, at the end), and the right one depends
     on its neighbours. Written in "logical" code points the letters have no shape yet.
  2. ORDER. Arabic is read right to left, but the Playdate draws from the left. The characters must be handed over in VISUAL order, the
     order they appear on the screen from left to right (and numbers or English words inside the Arabic keep their own left-to-right order).

THE SOLUTION
for_playdate(text) does both here on the computer: it replaces each letter with the code point of its correct shape (the "Arabic
Presentation Forms", U+FB50-U+FDFF and U+FE70-U+FEFF) and reorders the string into visual order. The app's font (made by
tools/make_arabic_font.py) holds one picture for each of those shapes, so the Playdate just draws the string as it is, and long titles
scroll as usual. Text with no Arabic in it is returned unchanged.

HOW THE SHAPES ARE FOUND
Python's own Unicode tables (unicodedata) already say which presentation form belongs to which letter: the decomposition of U+FEB1 is
"<isolated> 0633" and so on. _build_forms() turns those into a lookup table, so no table is typed in by hand.

LIMITS
Vowel marks (harakat, U+064B-U+065F) are removed: a font of fixed pictures cannot draw a mark above a letter. Song titles rarely have them.
The ordering is a compact version of the Unicode bidirectional algorithm: enough for titles like "اسم - Artist (2020)", not for deep nesting.
"""
import unicodedata

# ---- the letters and their shapes -------------------------------------------------------------------------------------------------

ISOLATED, INITIAL, MEDIAL, FINAL = "isolated", "initial", "medial", "final"
_FORMS = {}        # base letter -> {"isolated": ch, "initial": ch, "medial": ch, "final": ch} (only the shapes that exist)
_LIGATURES = {}    # (lam, alef variant) -> {"isolated": ch, "final": ch}   (lam + alef is drawn as one joined shape)
LAM = "ل"
_ALEFS = "آأإا"
_MARKS = set(range(0x064B, 0x0660)) | {0x0670} | set(range(0x06D6, 0x06DD)) | set(range(0x06DF, 0x06E9)) | set(range(0x06EA, 0x06EE))


def _build_forms():
    """Fills _FORMS and _LIGATURES from Python's Unicode data (the presentation-form code points name their base letters)."""
    for cp in list(range(0xFB50, 0xFDFC)) + list(range(0xFE70, 0xFEFD)):
        decomp = unicodedata.decomposition(chr(cp))
        if not decomp.startswith("<"):
            continue
        tag, _, rest = decomp.partition(" ")
        tag = tag.strip("<>")
        if tag not in (ISOLATED, INITIAL, MEDIAL, FINAL):
            continue
        bases = [chr(int(h, 16)) for h in rest.split()]
        if len(bases) == 1:
            _FORMS.setdefault(bases[0], {})[tag] = chr(cp)
        elif len(bases) == 2 and bases[0] == LAM and bases[1] in _ALEFS:
            _LIGATURES.setdefault((bases[0], bases[1]), {})[tag] = chr(cp)


_build_forms()


def _joins_next(ch):
    """True if this letter can connect to the letter AFTER it (it has a start or middle shape: ب س م ...; but not ا د ر و ...)."""
    return INITIAL in _FORMS.get(ch, {})


def _joins_prev(ch):
    """True if this letter can connect to the letter BEFORE it (every Arabic letter that has a final shape)."""
    return FINAL in _FORMS.get(ch, {})


def has_arabic(text):
    """True if the text has any Arabic-script character (basic letters or presentation forms)."""
    return any("؀" <= c <= "ۿ" or "ݐ" <= c <= "ݿ" or "ﭐ" <= c <= "﷿" or "ﹰ" <= c <= "﻿" for c in text)


def shape(text):
    """Replaces every Arabic letter with the shape it takes in this word (still in reading order). Marks are dropped."""
    chars = [c for c in text if ord(c) not in _MARKS]
    out = []
    n = len(chars)
    i = 0
    while i < n:
        c = chars[i]
        if c not in _FORMS:
            out.append(c)
            i += 1
            continue
        # does the letter before connect forward into this one?  (the previous output letter, if it is an Arabic letter)
        prev = chars[i - 1] if i > 0 else ""
        connect_prev = prev in _FORMS and _joins_next(prev) and _prev_connects(chars, i)
        # lam + alef: one ligature shape
        if c == LAM and i + 1 < n and (LAM, chars[i + 1]) in _LIGATURES:
            lig = _LIGATURES[(LAM, chars[i + 1])]
            out.append(lig.get(FINAL if connect_prev else ISOLATED, lig[ISOLATED]))
            i += 2
            continue
        nxt = chars[i + 1] if i + 1 < n else ""
        connect_next = _joins_next(c) and nxt in _FORMS and _joins_prev(nxt)
        if connect_prev and connect_next:
            kind = MEDIAL
        elif connect_prev:
            kind = FINAL
        elif connect_next:
            kind = INITIAL
        else:
            kind = ISOLATED
        shapes = _FORMS[c]
        out.append(shapes.get(kind) or shapes.get(ISOLATED) or c)
        i += 1
    return "".join(out)


def _prev_connects(chars, i):
    """The previous letter reaches forward into chars[i] only if chars[i] is itself a letter that can accept a connection."""
    return _joins_prev(chars[i])


# ---- the order ----------------------------------------------------------------------------------------------------------------------

_MIRROR = {"(": ")", ")": "(", "[": "]", "]": "[", "{": "}", "}": "{", "<": ">", ">": "<", "«": "»", "»": "«"}


def _kind(c):
    """'R' (reads right to left), 'L' (left to right: Latin letters and all digits), or 'N' (neutral: spaces and punctuation)."""
    cls = unicodedata.bidirectional(c)
    if cls in ("R", "AL"):
        return "R"
    if cls in ("L", "EN", "AN"):
        return "L"
    return "N"


def reorder(text):
    """Returns the text in the order it appears on screen from left to right (a compact form of the Unicode bidi algorithm)."""
    kinds = [_kind(c) for c in text]
    first = next((k for k in kinds if k != "N"), None)
    if first is None or "R" not in kinds:
        return text                                   # no right-to-left letters: nothing to reorder
    base = first                                      # the paragraph direction: the first strong letter decides
    n = len(text)
    # a pair of brackets is decided together (otherwise "(2020)" in Arabic text would come out as "(2020" and ")" far apart): if the
    # words inside go the same way as the paragraph the pair follows the paragraph; if they go the other way, the pair follows them
    # when the text just before the pair also went that way, and the paragraph otherwise
    stack = []
    for i, c in enumerate(text):
        if c in "([{<«":
            stack.append(i)
        elif c in ")]}>»" and stack:
            start = stack.pop()
            inside = {k for k in kinds[start + 1:i] if k != "N"}
            if not inside:
                continue
            before = next((k for k in reversed(kinds[:start]) if k != "N"), base)
            other = "L" if base == "R" else "R"
            if base in inside:
                resolved = base
            else:
                resolved = other if before == other else base
            kinds[start] = kinds[i] = resolved
    # neutrals take the direction of their neighbours if both sides agree, otherwise the paragraph's direction
    for i in range(n):
        if kinds[i] != "N":
            continue
        j = i
        while j < n and kinds[j] == "N":
            j += 1
        before = kinds[i - 1] if i > 0 else base
        after = kinds[j] if j < n else base
        fill = before if before == after else base
        for k in range(i, j):
            kinds[k] = fill
    # embedding levels: in a right-to-left paragraph R is level 1 and L is level 2; in a left-to-right paragraph L is 0 and R is 1
    if base == "R":
        levels = [1 if k == "R" else 2 for k in kinds]
    else:
        levels = [0 if k == "L" else 1 for k in kinds]
    # rule L2: from the highest level down to the lowest odd one, reverse every run at that level or above
    order = list(range(n))
    top = max(levels)
    lowest_odd = min((l for l in levels if l % 2 == 1), default=None)
    if lowest_odd is not None:
        for level in range(top, lowest_odd - 1, -1):
            i = 0
            while i < n:
                if levels[order[i]] >= level:
                    j = i
                    while j < n and levels[order[j]] >= level:
                        j += 1
                    order[i:j] = reversed(order[i:j])
                    i = j
                else:
                    i += 1
    out = []
    for idx in order:
        c = text[idx]
        out.append(_MIRROR.get(c, c) if levels[idx] % 2 == 1 else c)    # brackets turn around inside right-to-left text
    return "".join(out)


def for_playdate(text):
    """The one call the server needs: shaped, reordered text the Playdate can draw left to right. Other text is returned as it is."""
    if not text or not has_arabic(text):
        return text
    return reorder(shape(text))


def glyph_codepoints():
    """Every code point the Playdate's Arabic font needs a picture for (used by tools/make_arabic_font.py)."""
    cps = set()
    for shapes in _FORMS.values():
        cps.update(ord(c) for c in shapes.values())
    for lig in _LIGATURES.values():
        cps.update(ord(c) for c in lig.values())
    cps.update(range(0x0660, 0x066A))                 # Arabic-Indic digits ٠-٩
    cps.update(range(0x06F0, 0x06FA))                 # Persian digits ۰-۹
    cps.update({0x060C, 0x061B, 0x061F, 0x0640, 0x066B, 0x066C, 0x066A})   # ، ؛ ؟ tatweel, decimal and thousands marks, percent
    return sorted(cps)
