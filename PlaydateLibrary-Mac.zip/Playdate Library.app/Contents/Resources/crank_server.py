#!/usr/bin/env python3
"""crank_server.py: the home server of Crank Tunes. It lets a Playdate (on your Wi-Fi, or anywhere, see --key) play YOUR music and
remote-control the music app already playing on the computer (Spotify or Apple Music on a Mac; Spotify or any media player on Linux).
Runs on macOS and Linux.

    python3 crank_server.py --music ~/Music            # serve a folder of songs
    python3 crank_server.py --music ~/Music --kbps 96  # re-encode to 96 kbps first (lighter on the Playdate's Wi-Fi)
    python3 crank_server.py --music ~/Music --key s3cret   # require a password (needed before putting it on the internet)

Then put the address it prints (for example 192.168.1.20:8000) in the Playdate app's server.txt.

WHAT IT SERVES (plain HTTP; with --key every request except "/" must carry the key as ?k=... or an X-Crank-Key header):
  /library.txt          one line per song: id <TAB> artist <TAB> title <TAB> seconds
  /rescan               look at the music folder again (after songs were added or removed)
  /stream/<id>.mp3      the song as an MP3 stream (supports byte ranges, so the Playdate can seek)
  /cover/<id>.raw       the picture stored inside the song file, as a 96x96 1-bit picture (1152 bytes, white = 1); 404 if the file has none
  /now.txt              what the music app on this computer is playing (key=value lines)
  /control?cmd=...      playpause | next | prev | volume=<0-100> | seek=<seconds> | source=spotify|music
  /art.raw              the current album cover of the music app, as a 96x96 1-bit picture
                        (/art.raw?size=216: the big one, 216x216, 27 bytes a row, 5832 bytes)
  /info.txt             this server's version and whether it needs a key
  /                     a small web page with the address and the song list (open it on the computer to check)

WHAT IT NEEDS: Python 3. For lighter songs (--kbps) and for formats other than MP3 it needs `ffmpeg` (Linux: sudo apt install ffmpeg;
Mac: brew install ffmpeg, or on a Mac without it: `pip3 install --user lameenc` plus the built-in afconvert). For covers and album art it
needs Pillow (Linux: sudo apt install python3-pil; or pip3 install --user pillow). The Linux remote needs `playerctl` (sudo apt install playerctl).

IMPORTANT: this is for your OWN files. It is a private server for your Playdate. Anywhere the internet can reach it, use --key and HTTPS
(a tunnel such as Cloudflare Tunnel gives you HTTPS): see tunes/docs/LINUX_SERVER.md.
"""
import argparse
import hashlib
import hmac
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# Arabic titles are shaped and put in on-screen order here, because the Playdate can only draw left to right (see arabic_text.py). If the file
# is missing (an older install that only copied crank_server.py), titles are sent as they are.
try:
    from arabic_text import for_playdate
except ImportError:
    def for_playdate(text):
        return text

AUDIO_EXTENSIONS = (".mp3", ".m4a", ".aac", ".wav", ".aif", ".aiff", ".flac", ".ogg", ".opus")
VERSION = 2
IS_MAC = sys.platform == "darwin"


# ---------------------------------------------------------------- the song library

import re

# Words that mark a bracket as clutter ("(Official Audio)", "[Explicit]", "(Lyric Video)") rather than part of the title.
NOISE = re.compile(r"\s*[\(\[][^\)\]]*(official|audio|video|explicit|lyric|remaster|hd|hq|visuali[sz]er)[^\)\]]*[\)\]]", re.I)


def tidy_names(artist, title):
    """Cleans up a song's words for the Playdate's small screen: drops clutter in brackets, and when the file has no artist tag but is
    named "Artist - Title", splits that into the two parts. Returns (artist, title)."""
    title = NOISE.sub("", title).strip(" -")
    if not artist and " - " in title:
        left, right = title.split(" - ", 1)
        # never split at a dash that sits INSIDE a bracket (an opener without its closer before the dash); a complete pair, as in
        # "Name (Name2) - Song", is part of the artist and is fine
        open_bracket = left.count("(") > left.count(")") or left.count("[") > left.count("]")
        if 0 < len(left) <= 40 and right.strip() and not open_bracket:
            artist, title = left.strip(), right.strip()
    return artist.strip(), (title or "Untitled")


def read_id3(path):
    """Reads the title and artist from an MP3's ID3v2 tag (the common v2.3 and v2.4 forms) with no libraries.
    Returns a dict that may be missing keys. Anything unreadable just gives an empty dict."""
    out = {}
    try:
        with open(path, "rb") as f:
            head = f.read(10)
            if head[:3] != b"ID3":
                return out
            version = head[3]
            size = (head[6] << 21) | (head[7] << 14) | (head[8] << 7) | head[9]   # "synchsafe" 28-bit size
            data = f.read(size)
        i = 0
        while i + 10 <= len(data):
            frame_id = data[i:i + 4].decode("latin-1")
            if not frame_id.strip("\0"):
                break
            if version == 4:
                n = (data[i + 4] << 21) | (data[i + 5] << 14) | (data[i + 6] << 7) | data[i + 7]
            else:
                n = int.from_bytes(data[i + 4:i + 8], "big")
            body = data[i + 10:i + 10 + n]
            i += 10 + n
            if frame_id in ("TIT2", "TPE1", "TALB") and body:
                enc = body[0]
                raw = body[1:]
                codec = {0: "latin-1", 1: "utf-16", 2: "utf-16-be", 3: "utf-8"}.get(enc, "latin-1")
                text = raw.decode(codec, "replace").strip("\0 ﻿")
                out[{"TIT2": "title", "TPE1": "artist", "TALB": "album"}[frame_id]] = text.replace("\t", " ").replace("\n", " ")
    except OSError:
        pass
    return out


def audio_seconds(path):
    """The length of a song in seconds. Tries macOS's `afinfo` first, then `ffprobe` (installed with ffmpeg, so this
    is the one that works on Linux). 0 if neither can tell."""
    if shutil.which("afinfo"):
        try:
            text = subprocess.run(["afinfo", path], capture_output=True, text=True, timeout=20).stdout
            m = re.search(r"estimated duration:\s*([\d.]+)", text)
            if m:
                return float(m.group(1))
        except (OSError, subprocess.SubprocessError):
            pass
    if shutil.which("ffprobe"):
        try:
            text = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", path],
                                  capture_output=True, text=True, timeout=30).stdout
            return float(text.strip())
        except (OSError, ValueError, subprocess.SubprocessError):
            pass
    return 0.0


class Library:
    """The songs found in a folder, with a short stable id for each (a hash of its path), and an optional re-encode."""

    warned_no_converter = False   # set once the "no converter, sending MP3s as they are" note has been printed (see playable_path)

    def prewarm(self):
        """Converts every song that is not converted yet, one at a time, in a background thread (at low priority, see
        _reencode), so that pressing play on a song usually finds it ready. A request for a song that is still waiting
        simply converts it itself (the lock makes the two share the work, never repeat it)."""
        if not self.kbps or getattr(self, "_warming", False):
            return
        self._warming = True

        def work():
            try:
                for song in list(self.songs):
                    try:
                        self.playable_path(song)
                    except Exception as err:             # a broken file must not stop the others
                        print("prewarm skipped %s: %s" % (song.get("title"), err), flush=True)
            finally:
                self._warming = False

        threading.Thread(target=work, daemon=True).start()

    def rescan_if_changed(self):
        """Looks at the folder again only if its listing changed (a cheap check: names, sizes and times, no song is read).
        Called each time the Playdate loads the song list, so adding a song needs no restart and no /rescan."""
        try:
            stamp = sorted((n, os.path.getsize(os.path.join(self.folder, n)), int(os.path.getmtime(os.path.join(self.folder, n))))
                           for n in os.listdir(self.folder))
        except OSError:
            return
        if stamp != getattr(self, "_stamp", None):
            self._stamp = stamp
            self.scan()
            self.prewarm()

    def __init__(self, folder, kbps, cache_dir):
        self.folder = os.path.abspath(os.path.expanduser(folder))
        self.kbps = kbps
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        self.songs = []                   # dicts: id, path, artist, title, seconds
        self.lock = threading.Lock()      # one re-encode of a given song at a time
        self.scan()

    def scan(self):
        """Walks the folder and rebuilds the song list (sorted by artist, then title)."""
        found = []
        for root, _, files in os.walk(self.folder):
            for name in files:
                if name.startswith(".") or not name.lower().endswith(AUDIO_EXTENSIONS):
                    continue
                path = os.path.join(root, name)
                tags = read_id3(path) if name.lower().endswith(".mp3") else {}
                stem = os.path.splitext(name)[0].replace("_", " ")
                artist_name, title_name = tidy_names(tags.get("artist", ""), tags.get("title", stem))
                found.append({
                    "id": hashlib.sha1(os.path.relpath(path, self.folder).encode()).hexdigest()[:8],
                    "path": path,
                    "artist": artist_name,
                    "title": title_name,
                    "seconds": audio_seconds(path),
                })
        found.sort(key=lambda s: (s["artist"].lower(), s["title"].lower()))
        self.songs = found

    def find(self, song_id):
        """The song with this id, or None."""
        return next((s for s in self.songs if s["id"] == song_id), None)

    def cover(self, song):
        """The 96x96 1-bit cover stored in this song's file (kept once found), or None."""
        if "cover" not in song:
            song["cover"] = song_cover(song["path"])
        return song["cover"]

    def playable_path(self, song):
        """The file to send for a song: the original, or (with --kbps) a lighter MP3 made once and kept in the cache.

        Why re-encode: the Playdate's Wi-Fi measured about 18 KB/s from the internet, and a 192 kbps song needs 24 KB/s.
        96 kbps needs 12 KB/s. The MP3 decoder on the Playdate plays any MP3, so a lower bitrate just costs a little quality.
        """
        is_mp3 = song["path"].lower().endswith(".mp3")
        if not self.kbps:
            if is_mp3:
                return song["path"]
            # not an MP3 (the Playdate only decodes MP3): we must convert, at a sensible default
            return self._reencode(song, 128)
        try:
            return self._reencode(song, self.kbps)
        except RuntimeError as e:
            # No converter on this computer (a fresh Mac has neither ffmpeg nor lameenc, and the Mac app always asks for --kbps).
            # An MP3 can still be sent as it is: it may stutter on weak Wi-Fi if its bitrate is high, but it PLAYS, which beats
            # refusing every song. Other formats really do need converting, so for them the error stands. Said once, not per song.
            if not is_mp3:
                raise
            if not self.warned_no_converter:
                self.warned_no_converter = True
                sys.stderr.write("note: sending songs unshrunk (%s)\n" % e)
            return song["path"]

    def _reencode(self, song, kbps):
        """Makes <cache>/<id>_<kbps>.mp3 (44.1 kHz stereo). With ffmpeg (any computer) that is one command; on a Mac without ffmpeg,
        afconvert decodes and the lameenc library encodes. Raises RuntimeError with a plain message if neither is available."""
        out = os.path.join(self.cache_dir, "%s_%d.mp3" % (song["id"], kbps))
        if os.path.exists(out):
            return out                       # fast path: an already converted song must never queue behind another song's conversion
        with self.lock:
            if os.path.exists(out):          # (another request may have finished it while we waited)
                return out
            tmp = out + ".part"
            if shutil.which("ffmpeg"):
                subprocess.run((["nice", "-n", "10"] if shutil.which("nice") else []) + ["ffmpeg", "-y", "-loglevel", "error", "-i", song["path"], "-vn", "-map_metadata", "-1", "-ac", "2", "-ar", "44100",
                                "-codec:a", "libmp3lame", "-b:a", "%dk" % kbps, "-f", "mp3", tmp], check=True)
            elif IS_MAC and shutil.which("afconvert"):
                try:
                    import lameenc
                except ImportError:
                    raise RuntimeError("Re-encoding needs ffmpeg (brew install ffmpeg) or LAME: pip3 install --user lameenc")
                wav = out + ".wav"
                subprocess.run(["afconvert", "-f", "WAVE", "-d", "LEI16@44100", "-c", "2", song["path"], wav], check=True)
                with open(wav, "rb") as f:
                    pcm = f.read()
                os.remove(wav)
                pcm = pcm[44:]               # skip the 44-byte WAV header that afconvert writes
                enc = lameenc.Encoder()
                enc.set_bit_rate(kbps)
                enc.set_in_sample_rate(44100)
                enc.set_channels(2)
                enc.set_quality(5)           # 2 = best/slowest, 7 = fastest: 5 is a good middle for a small speaker
                with open(tmp, "wb") as f:
                    f.write(enc.encode(pcm) + enc.flush())
            else:
                raise RuntimeError("Re-encoding needs ffmpeg: sudo apt install ffmpeg  (Mac: brew install ffmpeg)")
            os.replace(tmp, out)             # appears whole, or not at all
            return out


# ---------------------------------------------------------------- pictures: from the songs and from the music app

BIG_ART = 216    # the big cover's width and height: a multiple of 8, so each row is a whole number of bytes


def to_1bit_96(image_bytes):
    """Any picture (JPEG, PNG...) as 96x96, 1 bit per pixel (12 bytes a row, 1152 bytes), white = 1, or None if it cannot be made.
    Cropped to a square, shrunk, and dithered (Floyd-Steinberg). The layout is the Playdate's own bitmap layout, so the app copies it straight in."""
    try:
        from io import BytesIO
        from PIL import Image
        img = Image.open(BytesIO(image_bytes)).convert("L")
        side = min(img.size)
        left, top = (img.width - side) // 2, (img.height - side) // 2
        img = img.crop((left, top, left + side, top + side)).resize((96, 96), Image.LANCZOS)
        return img.convert("1").tobytes()                 # Pillow's default dithering is Floyd-Steinberg
    except Exception:
        return None


def to_1bit_big(image_bytes):
    """Any picture as 216x216, 1 bit per pixel (27 bytes a row, 5832 bytes), white = 1, or None. Made for the big cover, so it works harder than
    to_1bit_96: the tones are stretched to use the full range, a little sharpening keeps edges and small lettering, and it is dithered with
    Atkinson's method, which spreads only 3/4 of each pixel's error and so keeps blacks and whites clean instead of grainy."""
    try:
        from io import BytesIO
        from PIL import Image, ImageFilter, ImageOps
        size = BIG_ART
        img = Image.open(BytesIO(image_bytes)).convert("L")
        side = min(img.size)
        left, top = (img.width - side) // 2, (img.height - side) // 2
        img = img.crop((left, top, left + side, top + side)).resize((size, size), Image.LANCZOS)
        img = ImageOps.autocontrast(img, cutoff=1).filter(ImageFilter.UnsharpMask(radius=1.2, percent=90, threshold=2))
        pixels = list(img.getdata())
        pixels = [float(p) for p in pixels]
        out = bytearray(BIG_ART // 8 * size)
        for y in range(size):
            for x in range(size):
                i = y * size + x
                white = pixels[i] >= 128
                err = (pixels[i] - (255 if white else 0)) / 8
                if white:
                    out[y * (size // 8) + x // 8] |= 0x80 >> (x & 7)
                for dx, dy in ((1, 0), (2, 0), (-1, 1), (0, 1), (1, 1), (0, 2)):    # six neighbours get 1/8 each
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < size and ny < size:
                        pixels[ny * size + nx] += err
        return bytes(out)
    except Exception:
        return None


def _syncsafe(b):
    return (b[0] << 21) | (b[1] << 14) | (b[2] << 7) | b[3]


def cover_from_mp3(path):
    """The picture stored in an MP3's ID3v2 tag (the APIC frame), as bytes, or None. Reads only the tag at the start of the file."""
    try:
        with open(path, "rb") as f:
            head = f.read(10)
            if head[:3] != b"ID3":
                return None
            version = head[3]
            size = _syncsafe(head[6:10])
            tag = f.read(min(size, 12 * 1024 * 1024))
        pos = 0
        while pos + 10 <= len(tag):
            frame_id = tag[pos:pos + 4]
            if frame_id[0] == 0:
                break
            fsize = _syncsafe(tag[pos + 4:pos + 8]) if version == 4 else int.from_bytes(tag[pos + 4:pos + 8], "big")
            body = tag[pos + 10:pos + 10 + fsize]
            pos += 10 + fsize
            if frame_id != b"APIC" or not body:
                continue
            enc = body[0]
            i = body.index(b"\0", 1) + 1                   # the MIME type, ends with a zero byte
            i += 1                                          # the picture type
            if enc in (1, 2):                               # UTF-16 text: the description ends with two zero bytes
                while i + 1 < len(body) and body[i:i + 2] != b"\0\0":
                    i += 2
                i += 2
            else:
                i = body.index(b"\0", i) + 1
            return body[i:]
    except (OSError, ValueError, IndexError):
        pass
    return None


def cover_from_m4a(path):
    """The picture in an M4A/MP4 file (the 'covr' atom), as bytes, or None."""
    try:
        with open(path, "rb") as f:
            data = f.read(20 * 1024 * 1024)
        i = data.find(b"covr")
        if i < 0:
            return None
        j = data.find(b"data", i)
        if j < 0:
            return None
        size = int.from_bytes(data[j - 4:j], "big")
        return data[j + 12:j - 4 + size]
    except (OSError, ValueError):
        return None


def cover_from_flac(path):
    """The picture in a FLAC file (a PICTURE metadata block), as bytes, or None."""
    try:
        with open(path, "rb") as f:
            if f.read(4) != b"fLaC":
                return None
            while True:
                h = f.read(4)
                if len(h) < 4:
                    return None
                last, kind, size = h[0] >> 7, h[0] & 0x7F, int.from_bytes(h[1:4], "big")
                block = f.read(size)
                if kind == 6:                                # PICTURE
                    p = 4
                    mlen = int.from_bytes(block[p:p + 4], "big"); p += 4 + mlen
                    dlen = int.from_bytes(block[p:p + 4], "big"); p += 4 + dlen
                    p += 16                                  # width, height, depth, colours
                    plen = int.from_bytes(block[p:p + 4], "big"); p += 4
                    return block[p:p + plen]
                if last:
                    return None
    except (OSError, ValueError):
        return None


def song_cover(path):
    """The 96x96 1-bit cover stored inside a song file, or None."""
    low = path.lower()
    raw = cover_from_mp3(path) if low.endswith(".mp3") else cover_from_m4a(path) if low.endswith((".m4a", ".aac")) else cover_from_flac(path) if low.endswith(".flac") else None
    return to_1bit_96(raw) if raw else None


# ---------------------------------------------------------------- remote control of Spotify / Apple Music

# The words each app uses in AppleScript. We read them with one script call so the fields match each other.
APPS = {
    "spotify": {"app": "Spotify", "duration_ms": True},
    "music": {"app": "Music", "duration_ms": False},
}


def run_osascript(script, timeout=4):
    """Runs an AppleScript and returns (output, error text). On any failure the output is ''. Never raises.
    The error text matters: error -1743 means macOS has not allowed this program to control that app (see Remote.now)."""
    try:
        r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=timeout)
        return (r.stdout.strip() if r.returncode == 0 else ""), r.stderr
    except (OSError, subprocess.SubprocessError):
        return "", "could not run osascript"


def app_running(app):
    """True if the app is already open. We check this first because merely talking to an app in AppleScript would LAUNCH it."""
    return run_osascript('application "%s" is running' % app)[0] == "true"


class MacRemote:
    """Reads and controls whichever of Spotify or Apple Music is open on this Mac (through AppleScript)."""

    def __init__(self, preferred=None):
        self.source = preferred            # "spotify", "music", or None (= whichever is playing, Spotify first)
        self.art_cache = {}                # (artwork url, big?) -> the 1-bit picture
        self.last_art_url = ""

    def choose(self):
        """Which app to talk to now: the chosen one if it is open, else the first open one."""
        order = [self.source] if self.source else []
        order += [k for k in ("spotify", "music") if k not in order]
        for key in order:
            if key and app_running(APPS[key]["app"]):
                return key
        return None

    def now(self):
        """What is playing, as a dict (state 'off' when nothing is open)."""
        key = self.choose()
        if key is None:
            return {"source": "none", "state": "off"}
        app = APPS[key]["app"]
        # The variable names are long on purpose: short ones like `st` and `t` collide with words in the scripting dictionaries on newer
        # macOS versions ("Expected expression but found st"), which made every status request fail.
        script = (
            'tell application "%s"\n'
            '  set pstate to player state as string\n'
            '  if pstate is "stopped" then return pstate\n'
            '  set trk to current track\n'
            '  set artwork_link to ""\n'
            '  try\n'
            '    set artwork_link to artwork url of trk\n'
            '  end try\n'
            '  return pstate & "||" & (name of trk) & "||" & (artist of trk) & "||" & (album of trk) & "||" & (duration of trk) & "||" & '
            '(player position) & "||" & (sound volume) & "||" & artwork_link\n'
            'end tell' % app)
        text, error = run_osascript(script)
        if not text:
            if "-1743" in error or "not allowed" in error.lower() or "not authorized" in error.lower():
                # macOS asks the FIRST time ("<program> wants to control <app>"); a "No" (or a missed window) is remembered, and then it
                # only works after switching it on in System Settings > Privacy & Security > Automation.
                sys.stderr.write("macOS has not allowed this program to control %s. Open System Settings > Privacy & Security > Automation "
                                 "and switch %s on for Terminal (or Python).\n" % (app, app))
                return {"source": key, "state": "blocked"}
            return {"source": key, "state": "unknown"}
        parts = text.split("||")
        if len(parts) < 7:
            return {"source": key, "state": parts[0]}
        duration = float(parts[4].replace(",", ".") or 0)
        if APPS[key]["duration_ms"]:
            duration /= 1000.0
        return {"source": key, "state": parts[0], "title": parts[1], "artist": parts[2], "album": parts[3],
                "duration": round(duration, 1), "position": round(float(parts[5].replace(",", ".") or 0), 1),
                "volume": int(float(parts[6].replace(",", ".") or 0)),
                "art": parts[7] if len(parts) > 7 else ""}

    def control(self, command, value=None):
        """Sends one command. Returns a short result string. `command` is playpause, next, prev, volume, seek or source."""
        if command == "source":
            self.source = value if value in APPS else None
            return "source=%s" % (self.source or "auto")
        key = self.choose()
        if key is None:
            return "error: no music app is open"
        app = APPS[key]["app"]
        scripts = {
            "playpause": 'tell application "%s" to playpause' % app,
            "next": 'tell application "%s" to next track' % app,
            "prev": 'tell application "%s" to previous track' % app,
        }
        if command == "volume" and value is not None:
            scripts["volume"] = 'tell application "%s" to set sound volume to %d' % (app, max(0, min(100, int(float(value)))))
        if command == "seek" and value is not None:
            scripts["seek"] = 'tell application "%s" to set player position to %s' % (app, float(value))
        if command not in scripts:
            return "error: unknown command"
        _, error = run_osascript(scripts[command])
        return "ok" if not error else "error: " + error.strip()[:80]

    def art_raw(self, url, big=False):
        """The music app's current album cover as 1-bit, 96x96 or (big) 216x216, or None. Made once per cover."""
        return cached_art(self, url, big)


ART_LOCK = threading.Lock()   # one cover conversion at a time: a request that arrives during the background preparation waits for it


def cached_art(remote, url, big=False):
    """Shared by both remotes: fetches a cover from an http(s) or file:// address, converts it, and keeps only the latest cover's pictures.

    The downloaded image is kept too (remote.art_data), so the second size is made from the same download instead of fetching it again.
    The lock means a Playdate request that arrives while prepare_art is still working simply waits for that work instead of repeating it."""
    if not url:
        return None
    with ART_LOCK:
        if (url, big) in remote.art_cache:
            return remote.art_cache[(url, big)]
        data = remote.art_data[1] if getattr(remote, "art_data", ("", b""))[0] == url else None
        if data is None:
            try:
                if url.startswith("file://"):
                    with open(urllib.parse.unquote(url[7:]), "rb") as f:
                        data = f.read()
                else:
                    with urllib.request.urlopen(url, timeout=6) as r:
                        data = r.read()
            except (OSError, ValueError):
                return None
            remote.art_data = (url, data)
        raw = to_1bit_big(data) if big else to_1bit_96(data)
        if raw is not None:
            keep = {key: value for key, value in remote.art_cache.items() if key[0] == url}   # this cover's other size stays
            keep[(url, big)] = raw
            remote.art_cache = keep
        return raw


def prepare_art(remote, url):
    """Makes both sizes of a new cover in the background, as soon as /now.txt sees a new song, so that the Playdate's two requests for
    it (small, then big) are answered at once instead of each waiting for a download and a conversion."""
    if not url or getattr(remote, "prepared_url", "") == url:
        return
    remote.prepared_url = url

    def work():
        remote.art_raw(url, False)
        remote.art_raw(url, True)
    threading.Thread(target=work, daemon=True).start()


class LinuxRemote:
    """Reads and controls whichever music player is open on this Linux computer, through `playerctl` (it speaks MPRIS, which Spotify's
    desktop app, VLC, Rhythmbox, mpv-mpris, spotifyd and most others support)."""

    def __init__(self, preferred=None):
        self.source = preferred            # "spotify" or None (= Spotify first, then whatever is open)
        self.art_cache = {}

    @staticmethod
    def _run(args, timeout=3):
        """Runs playerctl; returns its output, or '' on any failure. Never raises."""
        try:
            r = subprocess.run(["playerctl"] + args, capture_output=True, text=True, timeout=timeout)
            return r.stdout.strip() if r.returncode == 0 else ""
        except (OSError, subprocess.SubprocessError):
            return ""

    def choose(self):
        """The name of the player to talk to, or None."""
        names = [n for n in self._run(["-l"]).splitlines() if n.strip()]
        if not names:
            return None
        if self.source:
            for n in names:
                if n.startswith(self.source):
                    return n
        for n in names:
            if n.startswith("spotify"):
                return n
        return names[0]

    def now(self):
        if not shutil.which("playerctl"):
            return {"source": "none", "state": "off", "error": "playerctl is not installed"}
        player = self.choose()
        if player is None:
            return {"source": "none", "state": "off"}
        fmt = "{{status}}||{{title}}||{{artist}}||{{album}}||{{mpris:length}}||{{position}}||{{volume}}||{{mpris:artUrl}}"
        text = self._run(["-p", player, "metadata", "--format", fmt])
        source = "spotify" if player.startswith("spotify") else "player"
        if not text:
            return {"source": source, "state": "unknown"}
        parts = text.split("||")
        if len(parts) < 7:
            return {"source": source, "state": parts[0].lower()}
        def num(v, scale=1.0):
            try:
                return float(v) / scale
            except ValueError:
                return 0.0
        return {"source": source, "state": parts[0].lower(), "title": parts[1], "artist": parts[2], "album": parts[3],
                "duration": round(num(parts[4], 1e6), 1), "position": round(num(parts[5], 1e6), 1),
                "volume": int(num(parts[6]) * 100), "art": parts[7] if len(parts) > 7 else ""}

    def control(self, command, value=None):
        if command == "source":
            self.source = value or None
            return "source=%s" % (self.source or "auto")
        player = self.choose()
        if player is None:
            return "error: no music player is open"
        args = {"playpause": ["play-pause"], "next": ["next"], "prev": ["previous"]}.get(command)
        if command == "volume" and value is not None:
            args = ["volume", "%.2f" % (max(0, min(100, int(float(value)))) / 100.0)]
        if command == "seek" and value is not None:
            args = ["position", "%.1f" % float(value)]
        if args is None:
            return "error: unknown command"
        try:
            r = subprocess.run(["playerctl", "-p", player] + args, capture_output=True, text=True, timeout=3)
            return "ok" if r.returncode == 0 else "error: " + r.stderr.strip()[:80]
        except (OSError, subprocess.SubprocessError):
            return "error: playerctl failed"

    def art_raw(self, url, big=False):
        return cached_art(self, url, big)


def make_remote(preferred=None):
    """The remote that fits this computer."""
    return MacRemote(preferred) if IS_MAC else LinuxRemote(preferred)


# ---------------------------------------------------------------- the web server

def local_address(port):
    """This Mac's address on the home network, as 'ip:port' (found by asking the OS which interface reaches the outside)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))     # nothing is sent: this only makes the OS pick the right network interface
        return "%s:%d" % (s.getsockname()[0], port)
    except OSError:
        return "127.0.0.1:%d" % port
    finally:
        s.close()


def make_handler(library, remote, key=""):
    """Builds the request-handler class that knows about this library and remote. If `key` is set, every request except /info.txt must carry it."""

    failures = {}                     # client address -> (wrong keys so far, when counting started): too many wrong keys in a minute are refused

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def key_ok(self, query):
            """True if no key is needed, or the request carries the right one (as ?k=... or an X-Crank-Key header)."""
            if not key:
                return True
            ip = self.client_address[0]
            count, since = failures.get(ip, (0, time.time()))
            if time.time() - since > 60:
                count, since = 0, time.time()
            if count >= 20:
                return None            # locked out for now
            got = query.get("k", [""])[0] or self.headers.get("X-Crank-Key", "")
            if hmac.compare_digest(got.encode(), key.encode()):
                return True
            failures[ip] = (count + 1, since)
            return False

        def log_message(self, fmt, *args):
            """One short line per request on the Mac, so you can see the Playdate connecting."""
            sys.stderr.write("%s  %s  %s\n" % (time.strftime("%H:%M:%S"), self.client_address[0], fmt % args))

        def send_text(self, text, status=200, ctype="text/plain; charset=utf-8"):
            """Sends a small text answer."""
            body = text.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            """Routes a request to the right answer."""
            url = urllib.parse.urlparse(self.path)
            query = urllib.parse.parse_qs(url.query)
            if url.path == "/info.txt":                    # no key needed: lets an app or a person see what this is
                return self.send_text("crank_tunes_server\nversion=%d\nkey=%s\nplatform=%s\nsongs=%d\n" % (VERSION, "required" if key else "none", sys.platform, len(library.songs)))
            ok = self.key_ok(query)
            if ok is None:
                return self.send_text("too many wrong keys: wait a minute\n", 429)
            if not ok:
                return self.send_text("a key is needed\n", 403)
            if url.path.startswith("/cover/"):
                song = library.find(url.path[len("/cover/"):].split(".")[0])
                raw = library.cover(song) if song else None
                if raw is None:
                    return self.send_text("", 404)
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Length", str(len(raw)))
                self.send_header("Connection", "close")
                self.end_headers()
                return self.wfile.write(raw)
            if url.path == "/rescan":                      # the Playdate Library app asks for this after songs are added or removed
                library.scan()
                return self.send_text("%d songs\n" % len(library.songs))
            if url.path == "/library.txt":
                library.rescan_if_changed()      # songs added or removed since the last look show up without a restart
                lines = ["%s\t%s\t%s\t%d" % (s["id"], for_playdate(s["artist"]), for_playdate(s["title"]), round(s["seconds"])) for s in library.songs]
                return self.send_text("\n".join(lines) + "\n")
            if url.path.startswith("/stream/"):
                return self.stream(url.path[len("/stream/"):].split(".")[0])
            if url.path == "/now.txt":
                info = remote.now()
                remote.last_now = (time.time(), info)          # /art.raw reuses this instead of asking the music app again
                prepare_art(remote, info.get("art", ""))       # start making the new song's covers now, before the Playdate asks
                return self.send_text("\n".join("%s=%s" % (k, (for_playdate(str(v)) if k in ("title", "artist", "album") else str(v)).replace("\n", " "))
                                                  for k, v in info.items() if k != "art") + "\n")
            if url.path == "/control":
                for cmd in ("playpause", "next", "prev", "volume", "seek", "source"):
                    if cmd in query:
                        return self.send_text(remote.control(cmd, query[cmd][0]) + "\n")
                return self.send_text("error: no command\n", 400)
            if url.path == "/art.raw":
                # the cover's address: from the "what is playing?" answer of the last few seconds if there is one (asking the music app
                # again costs an AppleScript run, a few hundred milliseconds, for each of the two sizes); otherwise ask now
                when, info = getattr(remote, "last_now", (0, None))
                if info is None or time.time() - when > 5:
                    info = remote.now()
                raw = remote.art_raw(info.get("art", ""), query.get("size", [""])[0] == str(BIG_ART))
                if raw is None:
                    return self.send_text("", 404)
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Length", str(len(raw)))
                self.send_header("Connection", "close")
                self.end_headers()
                return self.wfile.write(raw)
            if url.path == "/":
                rows = "".join("<tr><td>%s</td><td>%s</td><td>%s</td></tr>" % (s["id"], s["artist"], s["title"]) for s in library.songs)
                page = "<h1>Crank Tunes server</h1><p>Address for the Playdate: <b>%s</b></p><table>%s</table>" % (local_address(self.server.server_port), rows)
                return self.send_text(page, ctype="text/html; charset=utf-8")
            self.send_text("not found\n", 404)

        def stream(self, song_id):
            """Sends one song, honouring a `Range: bytes=start-` request so a player can start in the middle."""
            song = library.find(song_id)
            if song is None:
                return self.send_text("no such song\n", 404)
            try:
                path = library.playable_path(song)
            except (RuntimeError, subprocess.CalledProcessError) as e:
                return self.send_text("could not prepare this song: %s\n" % e, 500)
            size = os.path.getsize(path)
            start, end = 0, size - 1
            m = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range", ""))
            if m:
                if m.group(1):
                    start = min(int(m.group(1)), size - 1)
                if m.group(2):
                    end = min(int(m.group(2)), size - 1)
            self.send_response(206 if m else 200)
            self.send_header("Content-Type", "audio/mpeg")
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(end - start + 1))
            if m:
                self.send_header("Content-Range", "bytes %d-%d/%d" % (start, end, size))
            self.send_header("Connection", "close")
            self.end_headers()
            try:
                with open(path, "rb") as f:
                    f.seek(start)
                    left = end - start + 1
                    while left > 0:
                        chunk = f.read(min(8192, left))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        left -= len(chunk)
            except (BrokenPipeError, ConnectionResetError):
                pass                      # the Playdate hung up (skipped the song): fine

    return Handler


def main():
    """Parses the options, scans the music folder and serves until Ctrl-C."""
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--music", default="~/Music", help="the folder of songs (default ~/Music)")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--kbps", type=int, default=0, help="re-encode every song to this bitrate first (96 or 128 suggested; 0 = send files as they are)")
    ap.add_argument("--prepare", action="store_true", help="with --kbps: re-encode everything now instead of on first play")
    ap.add_argument("--cache", default=os.path.expanduser("~/.crank_tunes_cache"), help="where re-encoded songs are kept")
    ap.add_argument("--source", choices=["spotify", "music"], help="which app to remote-control (default: whichever is open)")
    ap.add_argument("--key", default=os.environ.get("CRANK_KEY", ""), help="a password: every request must carry it (also read from the CRANK_KEY environment variable)")
    ap.add_argument("--bind", default="0.0.0.0", help="the address to listen on (0.0.0.0 = every network; 127.0.0.1 = only this computer, for use behind a tunnel)")
    args = ap.parse_args()

    library = Library(args.music, args.kbps, args.cache)
    remote = make_remote(args.source)
    print("found %d songs in %s" % (len(library.songs), library.folder))
    if args.prepare and args.kbps:
        for s in library.songs:
            print("  encoding", s["title"])
            library.playable_path(s)
    else:
        library.prewarm()            # convert the rest quietly in the background so the first play of each song is quick
    print("\nPut this in the Playdate app's server.txt:   %s%s\n" % (local_address(args.port), ("   " + args.key) if args.key else ""))
    httpd = ThreadingHTTPServer((args.bind, args.port), make_handler(library, remote, args.key))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("bye")


if __name__ == "__main__":
    main()
