#include <string.h>
#include "icy.h"

void icy_init(IcyParser* p, int metaint)
{
	p->metaint = metaint > 0 ? metaint : 0;
	p->untilMeta = p->metaint;
	p->metaLen = -1;
	p->metaGot = 0;
	p->title[0] = '\0';
	p->titleVersion++;
}

// Keep valid UTF-8 as is; replace anything else (e.g. Latin-1 bytes) with '?'
// so the Playdate font renderer never sees broken sequences.
static void copySanitized(char* dst, int cap, const char* src, int len)
{
	int o = 0;
	for (int i = 0; i < len && o < cap - 1; ) {
		unsigned char c = (unsigned char)src[i];
		int n = c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : (c >> 3) == 30 ? 4 : 0;
		int ok = n > 0 && i + n <= len;
		for (int k = 1; ok && k < n; k++) ok = ((unsigned char)src[i + k] >> 6) == 2;
		if (!ok) { dst[o++] = '?'; i++; continue; }
		if (o + n > cap - 1) break;
		if (n == 1 && c < 0x20) dst[o++] = ' ';
		else { memcpy(dst + o, src + i, (size_t)n); o += n; }
		i += n;
	}
	dst[o] = '\0';
}

static void parseMeta(IcyParser* p)
{
	p->meta[p->metaGot] = '\0';
	const char* key = "StreamTitle='";
	const char* start = strstr(p->meta, key);
	if (start == NULL) return;
	start += strlen(key);
	const char* end = strstr(start, "';");
	if (end == NULL) end = strrchr(start, '\'');
	if (end == NULL) return;

	char title[ICY_TITLE_MAX];
	copySanitized(title, sizeof title, start, (int)(end - start));
	if (strcmp(title, p->title) != 0) {
		strcpy(p->title, title);
		p->titleVersion++;
	}
}

int icy_filter(IcyParser* p, uint8_t* buf, int n)
{
	if (p->metaint == 0) return n;

	int in = 0, out = 0;
	while (in < n) {
		if (p->untilMeta > 0) {
			int k = n - in < p->untilMeta ? n - in : p->untilMeta;
			memmove(buf + out, buf + in, (size_t)k);
			in += k; out += k;
			p->untilMeta -= k;
		} else if (p->metaLen < 0) {
			p->metaLen = buf[in++] * 16;
			p->metaGot = 0;
			if (p->metaLen == 0) { p->metaLen = -1; p->untilMeta = p->metaint; }
		} else {
			int k = n - in < p->metaLen - p->metaGot ? n - in : p->metaLen - p->metaGot;
			memcpy(p->meta + p->metaGot, buf + in, (size_t)k);
			in += k;
			p->metaGot += k;
			if (p->metaGot == p->metaLen) {
				parseMeta(p);
				p->metaLen = -1;
				p->untilMeta = p->metaint;
			}
		}
	}
	return out;
}
