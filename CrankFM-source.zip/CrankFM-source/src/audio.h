// Audio callback: mixes the station (from the PCM ring) with radio static.
// Stereo in, stereo out on headphones; folded to mono for the speaker.
#ifndef AUDIO_H
#define AUDIO_H

#include "pd_api.h"
#include "ring.h"

typedef struct {
	PcmRing ring;              // decoded station audio (stereo frames)
	volatile int srcRate;      // sample rate of the ring's audio, 0 = none yet
	volatile int playing;      // main loop sets 1 once enough is buffered
	// Targets set by the main loop; the callback glides toward them per sample.
	volatile float stationGain;
	volatile float noiseGain;
	volatile float muffle;     // 0 = clear, 1 = heavily low-passed (mistuned)
	volatile float warble;     // pitch wobble depth (fraction of rate)
	volatile float volume;
	volatile int headphones;   // 1 = headphones plugged in (main loop sets it): real stereo
	volatile int underruns;
	volatile float level;      // peak level of the station audio (not the static), for visuals
} AudioState;

extern AudioState gAudio;

int audio_init(PlaydateAPI* pd, uint32_t ringSeconds);

#endif
