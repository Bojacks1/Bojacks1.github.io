#include <string.h>

#define MINIMP3_IMPLEMENTATION
#define MINIMP3_ONLY_MP3
#define MINIMP3_NO_SIMD
#include "minimp3.h"

#include "decoder.h"

// Keep this much buffered before decoding so minimp3 can see a whole frame
// (max 1441 bytes at 320kbps) plus the next header for sync.
#define MIN_INPUT 3000

struct Mp3Stream {
	mp3dec_t dec;
	uint8_t in[DECODER_IN_SIZE];
	int inLen;
	int sampleRate;
	int bitrate;
	int16_t pcm[MINIMP3_MAX_SAMPLES_PER_FRAME];
};

Mp3Stream* decoder_new(void* (*alloc)(void* ptr, size_t size))
{
	Mp3Stream* s = alloc(NULL, sizeof(Mp3Stream));
	if (s != NULL) decoder_reset(s);
	return s;
}

void decoder_reset(Mp3Stream* s)
{
	mp3dec_init(&s->dec);
	s->inLen = 0;
	s->sampleRate = 0;
	s->bitrate = 0;
}

uint8_t* decoder_input(Mp3Stream* s, int* space)
{
	*space = DECODER_IN_SIZE - s->inLen;
	return s->in + s->inLen;
}

void decoder_commit(Mp3Stream* s, int n) { s->inLen += n; }

static void consume(Mp3Stream* s, int n)
{
	if (n > s->inLen) n = s->inLen;
	memmove(s->in, s->in + n, (size_t)(s->inLen - n));
	s->inLen -= n;
}

int decoder_run(Mp3Stream* s, PcmRing* out, int maxFrames)
{
	int frames = 0;

	while (frames < maxFrames && s->inLen >= MIN_INPUT
		&& ring_space(out) >= MINIMP3_MAX_SAMPLES_PER_FRAME / 2)
	{
		mp3dec_frame_info_t info;
		int samples = mp3dec_decode_frame(&s->dec, s->in, s->inLen, s->pcm, &info);

		if (info.frame_bytes == 0) {
			// No frame found. If the buffer is full it's junk; drop most of it.
			if (s->inLen == DECODER_IN_SIZE) consume(s, DECODER_IN_SIZE - MIN_INPUT);
			break;
		}
		consume(s, info.frame_bytes);
		if (samples == 0) continue;   // skipped ID3 tag or invalid data

		s->sampleRate = info.hz;
		s->bitrate = info.bitrate_kbps;
		// Keep both channels (headphones get real stereo; the audio callback folds
		// it to mono for the speaker). A mono stream is stored as L == R.
		if (info.channels == 2) {
			for (int i = 0; i < samples; i++)
				ring_push(out, s->pcm[2 * i], s->pcm[2 * i + 1]);
		} else {
			for (int i = 0; i < samples; i++)
				ring_push(out, s->pcm[i], s->pcm[i]);
		}
		frames++;
	}
	return frames;
}

int decoder_sample_rate(const Mp3Stream* s) { return s->sampleRate; }
int decoder_bitrate(const Mp3Stream* s) { return s->bitrate; }
