// Icecast/Shoutcast "ICY" metadata: with `Icy-MetaData: 1`, the server inserts a
// block every `icy-metaint` audio bytes: one length byte (x16), then text such as
// StreamTitle='Artist - Song';  This strips those blocks and keeps the title.
// Platform-independent (host-testable).
#ifndef ICY_H
#define ICY_H

#include <stdint.h>

#define ICY_TITLE_MAX 128

typedef struct {
	int metaint;          // 0 = no metadata in this stream (pass-through)
	int untilMeta;        // audio bytes left before the next length byte
	int metaLen;          // size of the block being collected, -1 = expecting length byte
	int metaGot;
	char meta[16 * 255 + 1];
	char title[ICY_TITLE_MAX];
	int titleVersion;     // bumps whenever the title changes
} IcyParser;

void icy_init(IcyParser* p, int metaint);

// Filters n bytes in place; returns how many audio bytes remain at the front of buf.
int icy_filter(IcyParser* p, uint8_t* buf, int n);

#endif
