// Single-producer/single-consumer ring of stereo 16-bit PCM.
// The main loop writes decoded audio; the audio callback reads it.
// One "frame" is a left/right sample pair; indices and counts are in frames.
// (Mono sources are stored as L == R, so the rest of the code never special-cases them.)
#ifndef RING_H
#define RING_H

#include <stdint.h>

typedef struct {
	int16_t* data;           // interleaved L,R: 2 * cap entries
	uint32_t cap;            // frames; power of two
	volatile uint32_t w, r;  // free-running frame indices; count = w - r
} PcmRing;

static inline uint32_t ring_count(const PcmRing* rb) { return rb->w - rb->r; }
static inline uint32_t ring_space(const PcmRing* rb) { return rb->cap - (rb->w - rb->r); }

static inline void ring_push(PcmRing* rb, int16_t l, int16_t r)
{
	uint32_t i = (rb->w & (rb->cap - 1)) * 2;
	rb->data[i] = l;
	rb->data[i + 1] = r;
	rb->w = rb->w + 1;
}

// Frame at offset i from the read head (caller checks i < count).
static inline void ring_peek(const PcmRing* rb, uint32_t i, int16_t* l, int16_t* r)
{
	uint32_t k = ((rb->r + i) & (rb->cap - 1)) * 2;
	*l = rb->data[k];
	*r = rb->data[k + 1];
}

static inline void ring_drop(PcmRing* rb, uint32_t n) { rb->r = rb->r + n; }
static inline void ring_clear(PcmRing* rb) { rb->r = rb->w; }

#endif
