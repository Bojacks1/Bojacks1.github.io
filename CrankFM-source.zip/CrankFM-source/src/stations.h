#ifndef STATIONS_H
#define STATIONS_H

// YOUR STATIONS GO HERE.
//
// Crank FM was made for SomaFM's channels, but SomaFM does not allow third-party apps to use its streams, so this public copy
// comes with none. Put in stations whose owners allow it (many small and community stations do: ask them, and read their terms).
//
// What a station must be: an MP3 stream over plain http (no https: the Playdate's Wi-Fi is too slow to spare the encryption), at
// 128 kbps or less, ideally sending ICY song titles (the "Icy-MetaData" header; most Icecast and Shoutcast servers do). All of this
// copy's stations must be on ONE server (STREAM_HOST, STREAM_PORT): stream.c opens that host and asks for the station's path.

#define STREAM_HOST "radio.example.com"   // the stream server's name (no "http://")
#define STREAM_PORT 80

typedef struct {
	const char* name;    // short name drawn on the dial (about 6 letters)
	const char* title;   // full name, shown on the plate
	const char* path;    // the stream's path on the server, starting with "/", e.g. "/live.mp3"
} Station;

#define STATIONS_PER_BAND 6

typedef struct {
	const char* name;
	Station stations[STATIONS_PER_BAND];
} Band;

// Every band uses the same dial positions.
static const float kStationFreqs[STATIONS_PER_BAND] = { 89.5f, 92.7f, 96.1f, 99.9f, 103.3f, 106.7f };

// One band of six placeholders. Add more bands (up to six keys fit on the radio's front) by copying the block.
static const Band kBands[] = {
	{ "MY BAND", {
		{ "One",   "Station One",   "/one.mp3" },
		{ "Two",   "Station Two",   "/two.mp3" },
		{ "Three", "Station Three", "/three.mp3" },
		{ "Four",  "Station Four",  "/four.mp3" },
		{ "Five",  "Station Five",  "/five.mp3" },
		{ "Six",   "Station Six",   "/six.mp3" },
	} },
};
#define BAND_COUNT ((int)(sizeof(kBands) / sizeof(kBands[0])))

#define DIAL_MIN 88.0f
#define DIAL_MAX 108.0f

#endif
