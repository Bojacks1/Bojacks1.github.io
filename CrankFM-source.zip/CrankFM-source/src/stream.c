#include <stdarg.h>
#include <stdlib.h>
#include <strings.h>
#include <stdio.h>
#include <string.h>
#include "stream.h"
#include "decoder.h"
#include "audio.h"
#include "icy.h"

// Adaptive buffer. Normally we keep BASE_TARGET seconds decoded ahead, which keeps
// tuning snappy. When the Wi-Fi struggles (the buffer runs low or dries up), the
// target grows in steps up to MAX_TARGET so the next hiccup is absorbed instead of
// heard; after a long calm spell it shrinks back. (The ring in main.c must hold
// MAX_TARGET seconds.)
#define START_SECONDS 1.0f      // buffered audio needed before playback starts (normal case)
#define BASE_TARGET 3.0f        // seconds to keep decoded ahead when the network is fine
#define MAX_TARGET 10.0f        // ...and the most we will ever ask for
#define TARGET_STEP 3.0f        // growth per trouble event
#define LOW_WATER 0.4f          // buffered seconds below which we call it "running low"
#define ESCALATE_GAP_MS 8000    // at most one growth step per this long (one dip isn't a trend)
#define CALM_MS 180000          // this long without trouble: shrink the target by 1s
#define FRAMES_PER_UPDATE 8     // decode budget per frame (~0.2s of audio)
#define RETRY_MS 3000
// Some servers reject unknown default agents; Icy-MetaData asks for in-stream song titles.
#define HEADERS "User-Agent: PlaydateRadio/0.1\r\nIcy-MetaData: 1"

static PlaydateAPI* pd;
static const struct playdate_http* http;
static Mp3Stream* dec;
static HTTPConnection* conn;
static StreamState state = STREAM_NEED_ACCESS;
static const Station* current;    // station being streamed
static const Station* wanted;     // station the dial is on
static unsigned int retryAt;
static unsigned int generation;   // ignores callbacks from connections we've dropped
static int pendingStatus;         // set by callbacks, handled in stream_update
static int pendingClosed;
static int pendingComplete;
static int pendingMetaint;        // from the icy-metaint response header
static IcyParser icy;
static float targetSeconds = BASE_TARGET;   // current buffer target (grows on Wi-Fi trouble)
static unsigned int lastEscalateAt, lastTroubleAt;
static int rebuffering;           // ran dry after playing: show "buffering" and refill deeper
static SDFile* logFile;
static int bytesRead, framesDecoded;
static unsigned int statsAt;

// Log to the console and to radio.log in the game's data folder
// (Simulator: ~/Developer/PlaydateSDK/Disk/Data/com.braq.radio/radio.log).
void dlog(const char* fmt, ...)
{
	char buf[256];
	va_list ap;
	va_start(ap, fmt);
	int n = vsnprintf(buf, sizeof buf - 1, fmt, ap);
	va_end(ap);
	if (n < 0) return;
	if (n > (int)sizeof buf - 2) n = (int)sizeof buf - 2;
	pd->system->logToConsole("radio: %s", buf);
	if (logFile != NULL) {
		char line[280];
		int m = snprintf(line, sizeof line, "%u %s\n", pd->system->getCurrentTimeMilliseconds(), buf);
		pd->file->write(logFile, line, (unsigned int)m);
		pd->file->flush(logFile);
	}
}

static void closeConnection(void)
{
	if (conn != NULL) {
		// close() also frees the connection: calling release() after it double-freed
		// and crashed the Simulator on the next station change.
		http->setUserdata(conn, NULL);
		http->close(conn);
		conn = NULL;
	}
	gAudio.playing = 0;           // callback stops reading before we clear
	rebuffering = 0;
	ring_clear(&gAudio.ring);
	decoder_reset(dec);
	icy_init(&icy, 0);
	current = NULL;
}

static void fail(void)
{
	closeConnection();
	state = STREAM_ERROR;
	retryAt = pd->system->getCurrentTimeMilliseconds() + RETRY_MS;
}

static int isLive(HTTPConnection* c)
{
	return c == conn && http->getUserdata(c) == (void*)(uintptr_t)generation;
}

// Callbacks only record what happened; closing a connection from inside its own
// callback isn't safe, so stream_update acts on these.
static void onHeadersRead(HTTPConnection* c)
{
	if (isLive(c)) pendingStatus = http->getResponseStatus(c);
}

static void onClosed(HTTPConnection* c)
{
	if (isLive(c)) pendingClosed = 1;
}

static void onComplete(HTTPConnection* c)
{
	if (isLive(c)) pendingComplete = 1;
}

static void onHeader(HTTPConnection* c, const char* key, const char* value)
{
	if (key == NULL || value == NULL || !isLive(c)) return;
	dlog("header %s: %s", key, value);
	if (strcasecmp(key, "icy-metaint") == 0) pendingMetaint = atoi(value);
}

static void openStation(const Station* station)
{
	closeConnection();
	generation++;
	pendingStatus = pendingClosed = pendingComplete = pendingMetaint = 0;
	bytesRead = framesDecoded = 0;
	char path[64];
	snprintf(path, sizeof path, "%s", station->path);   // each station names its own path (see stations.h)
	dlog("open %s%s", STREAM_HOST, path);
	current = station;
	conn = http->newConnection(STREAM_HOST, STREAM_PORT, false);
	if (conn == NULL) { fail(); return; }
	http->setUserdata(conn, (void*)(uintptr_t)generation);
	http->setConnectTimeout(conn, 10000);
	http->setReadTimeout(conn, 10000);
	http->setReadBufferSize(conn, 64 * 1024);
	http->setHeadersReadCallback(conn, onHeadersRead);
	http->setHeaderReceivedCallback(conn, onHeader);
	http->setConnectionClosedCallback(conn, onClosed);
	http->setRequestCompleteCallback(conn, onComplete);   // a live stream should never complete

	PDNetErr err = http->get(conn, path, HEADERS, strlen(HEADERS));
	if (err != NET_OK) {
		dlog("get() failed %d", err);
		fail();
		return;
	}
	state = STREAM_CONNECTING;
}

static void onAccess(bool allowed, void* ud)
{
	(void)ud;
	dlog("access callback: %s", allowed ? "allowed" : "denied");
	state = allowed ? STREAM_IDLE : STREAM_DENIED;
}

// Opens radio.log as early as possible so startup problems on the device leave a trail.
void dlog_init(PlaydateAPI* playdate)
{
	pd = playdate;
	if (logFile == NULL) logFile = pd->file->open("radio.log", kFileWrite);
}

static void onWifi(PDNetErr err)
{
	dlog("wifi enable callback: err %d", err);
}

void stream_init(PlaydateAPI* playdate)
{
	pd = playdate;
	http = pd->network->http;
	dec = decoder_new(pd->system->realloc);
	dlog_init(playdate);
	dlog("init, wifi status %d", pd->network->getStatus());
	dlog("stream_init: decoder %p, http %p", (void*)dec, (void*)http);
	pd->network->setEnabled(true, onWifi);   // start joining Wi-Fi now; it can take ~10s
	dlog("stream_init: setEnabled returned");
}

// The access dialog is requested from the update loop rather than at init.
static void requestAccess(void)
{
	static int requested;
	if (requested) return;
	requested = 1;
	enum accessReply r = http->requestAccess(STREAM_HOST, STREAM_PORT, false,
		"to stream internet radio", onAccess, NULL);
	dlog("requestAccess -> %d (0 ask, 1 deny, 2 allow)", r);
	if (r == kAccessAllow) state = STREAM_IDLE;
	else if (r == kAccessDeny) state = STREAM_DENIED;
}

void stream_tune(const Station* station)
{
	if (station == wanted) return;   // same station: stream_update handles retries
	wanted = station;
	if (state == STREAM_NEED_ACCESS || state == STREAM_DENIED) return;
	if (station == NULL) {
		closeConnection();
		state = STREAM_IDLE;
	} else {
		openStation(station);
	}
}

/**
 * Called when the audio ran low or dry while playing, i.e. the Wi-Fi isn't keeping
 * up. Grows the buffer target one step (at most once per ESCALATE_GAP_MS, so a
 * single dip doesn't jump straight to the maximum).
 */
static void wifiTrouble(unsigned int now, const char* why)
{
	lastTroubleAt = now;
	if (targetSeconds >= MAX_TARGET || now - lastEscalateAt < ESCALATE_GAP_MS) return;
	lastEscalateAt = now;
	targetSeconds += TARGET_STEP;
	if (targetSeconds > MAX_TARGET) targetSeconds = MAX_TARGET;
	dlog("wi-fi trouble (%s): buffer target now %.0fs", why, (double)targetSeconds);
}

void stream_update(void)
{
	if (state == STREAM_NEED_ACCESS) requestAccess();
	if (state == STREAM_NEED_ACCESS || state == STREAM_DENIED) return;

	if (state == STREAM_ERROR || state == STREAM_IDLE) {
		if (wanted != NULL && (state == STREAM_IDLE
			|| pd->system->getCurrentTimeMilliseconds() >= retryAt))
			openStation(wanted);
		return;
	}
	if (conn == NULL) return;

	if (pendingStatus != 0) {
		if (pendingStatus != 200) {
			dlog("HTTP status %d", pendingStatus);
			fail();
			return;
		}
		dlog("HTTP status 200");
		pendingStatus = 0;
		if (state == STREAM_CONNECTING) state = STREAM_BUFFERING;
	}

	if (pendingMetaint != 0) {    // must be set before the first body byte is parsed
		icy_init(&icy, pendingMetaint);
		pendingMetaint = 0;
	}

	// Network -> decoder input (ICY metadata blocks stripped in place)
	size_t avail = http->getBytesAvailable(conn);
	while (avail > 0) {
		int space;
		uint8_t* dst = decoder_input(dec, &space);
		if (space <= 0) break;
		int n = http->read(conn, dst, (unsigned int)(avail < (size_t)space ? avail : (size_t)space));
		if (n <= 0) break;
		bytesRead += n;
		decoder_commit(dec, icy_filter(&icy, dst, n));
		avail = http->getBytesAvailable(conn);
	}

	static int loggedTitle;
	if (icy.titleVersion != loggedTitle) {
		loggedTitle = icy.titleVersion;
		if (icy.title[0] != '\0') dlog("title: %s", icy.title);
	}

	// Decoder -> PCM ring, up to the target buffer
	int rate = decoder_sample_rate(dec);
	if (rate == 0 || stream_buffered_seconds() < targetSeconds)
		framesDecoded += decoder_run(dec, &gAudio.ring, FRAMES_PER_UPDATE);
	rate = decoder_sample_rate(dec);
	gAudio.srcRate = rate;

	unsigned int now = pd->system->getCurrentTimeMilliseconds();
	if (now >= statsAt) {
		statsAt = now + 1000;
		dlog("state %d bytes %d frames %d buffered %.2fs target %.0fs underruns %d",
			state, bytesRead, framesDecoded, (double)stream_buffered_seconds(),
			(double)targetSeconds, gAudio.underruns);
	}

	if (pendingClosed || pendingComplete) {
		dlog("connection %s (err %d, status %d, bytes %d)", pendingClosed ? "closed" : "complete",
			http->getError(conn), http->getResponseStatus(conn), bytesRead);
		fail();
		return;
	}

	float buffered = stream_buffered_seconds();
	// How much to have before (re)starting playback: a little more once the buffer
	// has been boosted, and after a dry-out a good part of the target, so the
	// stream doesn't stutter straight back into silence.
	float startNeeded = rebuffering ? 0.6f * targetSeconds
		: START_SECONDS + 0.4f * (targetSeconds - BASE_TARGET);
	if (state == STREAM_BUFFERING && rate > 0 && buffered >= startNeeded) {
		state = STREAM_PLAYING;
		rebuffering = 0;
		gAudio.playing = 1;
	} else if (state == STREAM_PLAYING && buffered < 0.05f) {
		state = STREAM_BUFFERING;   // ran dry: static covers it until we refill
		gAudio.playing = 0;
		rebuffering = 1;
		wifiTrouble(now, "ran dry");
	} else if (state == STREAM_PLAYING) {
		if (buffered < LOW_WATER) wifiTrouble(now, "running low");
		else if (targetSeconds > BASE_TARGET && now - lastTroubleAt > CALM_MS) {
			targetSeconds -= 1.0f;               // calm for a long while: ease back
			if (targetSeconds < BASE_TARGET) targetSeconds = BASE_TARGET;
			lastTroubleAt = now;
			dlog("wi-fi calm: buffer target back to %.0fs", (double)targetSeconds);
		}
	}
}

StreamState stream_state(void) { return state; }

int stream_rebuffering(void) { return rebuffering; }

float stream_buffered_seconds(void)
{
	int rate = decoder_sample_rate(dec);
	return rate > 0 ? (float)ring_count(&gAudio.ring) / (float)rate : 0.0f;
}

int stream_bitrate(void) { return decoder_bitrate(dec); }

const char* stream_title(void) { return icy.title; }
