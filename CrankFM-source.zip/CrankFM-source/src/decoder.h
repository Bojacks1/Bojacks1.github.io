// MP3 byte stream -> stereo PCM ring. Platform-independent (host-testable).
#ifndef DECODER_H
#define DECODER_H

#include <stdint.h>
#include "ring.h"

#define DECODER_IN_SIZE 16384

typedef struct Mp3Stream Mp3Stream;

Mp3Stream* decoder_new(void* (*alloc)(void* ptr, size_t size));
void decoder_reset(Mp3Stream* s);

// Space for incoming bytes: write up to *space bytes at the returned pointer, then commit.
uint8_t* decoder_input(Mp3Stream* s, int* space);
void decoder_commit(Mp3Stream* s, int n);

// Decode up to maxFrames MP3 frames into the ring (only while it has room for a
// whole frame). Returns frames decoded.
int decoder_run(Mp3Stream* s, PcmRing* out, int maxFrames);

int decoder_sample_rate(const Mp3Stream* s);   // 0 until the first frame decodes
int decoder_bitrate(const Mp3Stream* s);       // kbps

#endif
