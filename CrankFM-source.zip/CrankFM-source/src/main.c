// Crank FM: tune internet radio with the crank. The screen is the front
// of a tabletop radio: dial window, speaker grille, label plate, preset keys.
#include <math.h>
#include <stdio.h>
#include <string.h>

#include "pd_api.h"
#include "audio.h"
#include "stream.h"
#include "stations.h"

#define SCREEN_DUMP 0        // 1: write the screen to screen.pbm every 3s (debug)
#define CLIP_CAPTURE 0       // 1: once the music has played for a few seconds, save 300 frames as cap_0000.pbm... (for the website's looping clip). Never ship with 1.
#define DEBUG_AUTO_B 0       // 1: press B every 6s (station-switch soak test; Simulator builds ignore make UDEFS)

// Tuning feel
#define MHZ_PER_REV 4.0f     // one crank turn sweeps 4 MHz (5 turns end to end)
#define CAPTURE 0.6f         // MHz: a station starts breaking through the static
#define SEEK_SPEED 10.0f     // MHz/s when seeking with the D-pad
#define DWELL_MS 250         // stay near a station this long before connecting
#define DROP_MS 2000         // keep the connection this long after tuning away
#define SAVE_DELAY_MS 1500   // save settings once they've stopped changing
#define MARQUEE_SPEED 30.0f  // px/s for song titles too wide to fit
#define HINT_SECONDS 6.0f    // controls card on first launch
#define SPLASH_SECONDS 2.0f  // Boraq's launch screen stays up at least this long

// Layout: cabinet, dial window (top), grille (left), label plate (right), preset keys (bottom)
#define WIN_X 16
#define WIN_Y 14
#define WIN_W 368
#define WIN_H 80
#define SCALE_X0 (WIN_X + 16)
#define SCALE_X1 (WIN_X + WIN_W - 16)
#define SCALE_Y (WIN_Y + 50)
#define GRILLE_X 16
#define GRILLE_Y 110
#define GRILLE_W 156
#define GRILLE_H 90
#define PLATE_X 182
#define PLATE_Y 110
#define PLATE_W 202
#define PLATE_H 90
#define KEYS_X 16
#define KEYS_Y 207
#define KEYS_W 368
#define KEYS_H 22
#define KEY_GAP 4

#define SETTINGS_FILE "settings.txt"

static PlaydateAPI* pd;
static LCDFont* font;        // Asheville Sans 14 Bold
static LCDFont* small;       // Roobert 10 Bold
static LCDFont* light;       // Asheville Sans 14 Light: has the button glyphs (Ⓐ ⬅️ ...)
static LCDBitmap* cabinet;   // everything that never moves, drawn once
static LCDBitmap* splash;    // launcher/launchImage (Boraq), shown at startup
static float splashTimer = SPLASH_SECONDS;

static int band;
static float freq = 89.5f;
static float seekTarget = -1.0f;
static const Station* candidate;
static unsigned int candidateSince;
static float quality;        // 0..1 how well tuned the nearest station is
static float marquee;
static unsigned int dirtySince;   // 0 = settings saved
static int hintsSeen;
static int aboutSeen;        // the credits card has been shown once (saved)
static float hintTimer;

// Animated parts
static float sigLevel;                     // smoothed signal strength for the bars
static float pulse;                        // grille pulse radius (px)

static LCDPattern kGlow50 = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,   // black where opaque
	0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55, 0xAA, 0x55,   // mask: checkerboard
};
static LCDPattern kGlow25 = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x88, 0x00, 0x22, 0x00, 0x88, 0x00, 0x22, 0x00,
};

static float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static float rad(float deg) { return deg * 3.14159265f / 180.0f; }

// ---- settings ----

static void loadSettings(void)
{
	SDFile* f = pd->file->open(SETTINGS_FILE, kFileReadData);
	if (f == NULL) return;
	char buf[128];
	int n = pd->file->read(f, buf, sizeof buf - 1);
	pd->file->close(f);
	if (n <= 0) return;
	buf[n] = '\0';
	int b = 0, hints = 0, about = 0;
	float fr = freq, vol = gAudio.volume;
	// hints= and about= are optional, so settings files from older builds still load.
	if (sscanf(buf, "band=%d freq=%f volume=%f hints=%d about=%d", &b, &fr, &vol, &hints, &about) >= 3) {
		band = b >= 0 && b < BAND_COUNT ? b : 0;
		freq = clampf(fr, DIAL_MIN, DIAL_MAX);
		gAudio.volume = clampf(vol, 0.0f, 1.0f);
		hintsSeen = hints;
		aboutSeen = about;
	}
}

static void saveSettings(void)
{
	SDFile* f = pd->file->open(SETTINGS_FILE, kFileWrite);
	if (f == NULL) return;
	char buf[128];
	int n = snprintf(buf, sizeof buf, "band=%d freq=%.2f volume=%.2f hints=%d about=%d\n",
		band, (double)freq, (double)gAudio.volume, hintsSeen, aboutSeen);
	pd->file->write(f, buf, (unsigned int)n);
	pd->file->close(f);
	dirtySince = 0;
}

static void markDirty(void)
{
	dirtySince = pd->system->getCurrentTimeMilliseconds();
	if (dirtySince == 0) dirtySince = 1;
}

/**
 * Headphone plug/unplug callback. Registering a callback turns off the system's
 * automatic speaker/headphone switching, so we redo it by hand: headphones in means
 * headphones only, out means speaker. The audio callback reads gAudio.headphones to
 * decide between real stereo (headphones) and a mono fold-down (the mono speaker).
 * (Never pass NULL here: the device may call the callback even when it is NULL.)
 */
static void onHeadphones(int headphone, int mic)
{
	(void)mic;
	gAudio.headphones = headphone;
	pd->sound->setOutputsActive(headphone, !headphone);
	dlog("headphones %s", headphone ? "in: stereo" : "out: mono speaker");
}

static void setupHeadphones(void)
{
	int hp = 0, mic = 0;
	pd->sound->getHeadphoneState(&hp, &mic, onHeadphones);
	onHeadphones(hp, mic);   // apply the state we start in
}

static void showControls(void* ud) { (void)ud; hintTimer = HINT_SECONDS; }

// The credits card. It opens by itself on the very first launch, and any time
// from the system menu -> "about". Unlike the controls card it stays up until a
// button is pressed, because people read credits at their own pace.
static int aboutOpen;
static int controlsAfterAbout;   // first launch: show the controls card once credits close
static void showAbout(void* ud) { (void)ud; aboutOpen = 1; hintTimer = 0.0f; }

/**
 * Closes the credits card. The first time, this also remembers that it has been
 * seen (so it never pops up again on its own) and hands over to the controls
 * card if that is also still unseen: the two cards would otherwise overlap.
 */
static void closeAbout(void)
{
	aboutOpen = 0;
	if (!aboutSeen) { aboutSeen = 1; markDirty(); }
	if (controlsAfterAbout) { controlsAfterAbout = 0; hintTimer = HINT_SECONDS; }
}

// ---- tuning ----

static int nearestStation(float f, float* dist)
{
	int best = 0;
	for (int i = 1; i < STATIONS_PER_BAND; i++)
		if (fabsf(kStationFreqs[i] - f) < fabsf(kStationFreqs[best] - f)) best = i;
	*dist = fabsf(kStationFreqs[best] - f);
	return best;
}

static void handleInput(float dt)
{
	PDButtons current, pushed, released;
	pd->system->getButtonState(&current, &pushed, &released);
	float before = freq, volBefore = gAudio.volume;

	if (pushed && aboutOpen) {              // any button closes the credits card
		closeAbout();
		pushed = 0;
	}
	if (pushed && hintTimer > 0.0f) {       // any button dismisses the controls card
		hintTimer = 0.0f;
		pushed = 0;
	}

	float crank = pd->system->getCrankChange();
	if (crank != 0.0f) seekTarget = -1.0f;   // the hand on the dial wins
	freq += crank / 360.0f * MHZ_PER_REV;

	float dist;
	int near = nearestStation(freq, &dist);
	if (pushed & kButtonRight) {
		for (int i = 0; i < STATIONS_PER_BAND; i++)
			if (kStationFreqs[i] > freq + 0.05f) { seekTarget = kStationFreqs[i]; break; }
	}
	if (pushed & kButtonLeft) {
		for (int i = STATIONS_PER_BAND - 1; i >= 0; i--)
			if (kStationFreqs[i] < freq - 0.05f) { seekTarget = kStationFreqs[i]; break; }
	}
	if ((pushed & kButtonA) && dist < CAPTURE) seekTarget = kStationFreqs[near];   // fine-tune
#if DEBUG_AUTO_B
	{ static float t; t += dt; if (t > 6.0f) { t = 0.0f; pushed |= kButtonB; } }
#endif
	if (pushed & kButtonB) { band = (band + 1) % BAND_COUNT; markDirty(); }

	if (seekTarget >= 0.0f) {
		float step = SEEK_SPEED * dt;
		if (fabsf(seekTarget - freq) <= step) { freq = seekTarget; seekTarget = -1.0f; }
		else freq += seekTarget > freq ? step : -step;
	}
	freq = clampf(freq, DIAL_MIN, DIAL_MAX);

	if (current & kButtonUp) gAudio.volume = clampf(gAudio.volume + dt * 0.8f, 0.0f, 1.0f);
	if (current & kButtonDown) gAudio.volume = clampf(gAudio.volume - dt * 0.8f, 0.0f, 1.0f);

	if (freq != before || gAudio.volume != volBefore) markDirty();
}

// Connect when the dial settles near a station; disconnect a while after leaving.
static void manageStream(const Station* near, float dist)
{
	const Station* want = dist < CAPTURE ? near : NULL;
	unsigned int now = pd->system->getCurrentTimeMilliseconds();
	if (want != candidate) { candidate = want; candidateSince = now; }
	if (now - candidateSince >= (candidate != NULL ? DWELL_MS : DROP_MS))
		stream_tune(candidate);
	stream_update();
}

static void updateAudioTargets(float dist)
{
	float q = clampf(1.0f - dist / CAPTURE, 0.0f, 1.0f);
	q = q * q * (3.0f - 2.0f * q);                 // smoothstep: flat and clear near the centre
	quality = q;
	float heard = stream_state() == STREAM_PLAYING ? q : 0.0f;

	gAudio.stationGain = heard;
	gAudio.noiseGain = 1.0f - 0.93f * heard;       // a whisper of hiss even when locked
	gAudio.muffle = 0.9f * (1.0f - q);
	gAudio.warble = 0.03f * (1.0f - q);
}

static void animate(float dt)
{
	float target = quality * (stream_state() == STREAM_PLAYING ? 1.0f : 0.35f);
	sigLevel += (target - sigLevel) * clampf(8.0f * dt, 0.0f, 1.0f);

	float level = stream_state() == STREAM_PLAYING ? gAudio.level : 0.0f;
	float r = clampf(level * 1.8f, 0.0f, 1.0f) * 50.0f;
	pulse += (r - pulse) * (r > pulse ? 0.6f : 0.15f);   // fast attack, slow release
}

// ---- drawing helpers ----

static int textWidth(LCDFont* f, const char* s)
{
	return pd->graphics->getTextWidth(f, s, strlen(s), kUTF8Encoding, 0);
}

static void text(const char* s, int x, int y)
{
	pd->graphics->drawText(s, strlen(s), kUTF8Encoding, x, y);
}

static void textCentered(LCDFont* f, const char* s, int cx, int y)
{
	pd->graphics->setFont(f);
	text(s, cx - textWidth(f, s) / 2, y);
}

static void roundRect(int x, int y, int w, int h, int r, int lw)
{
	LCDColor c = kColorBlack;
	pd->graphics->fillRect(x + r, y, w - 2 * r, lw, c);
	pd->graphics->fillRect(x + r, y + h - lw, w - 2 * r, lw, c);
	pd->graphics->fillRect(x, y + r, lw, h - 2 * r, c);
	pd->graphics->fillRect(x + w - lw, y + r, lw, h - 2 * r, c);
	pd->graphics->drawEllipse(x, y, 2 * r, 2 * r, lw, 270.0f, 360.0f, c);
	pd->graphics->drawEllipse(x + w - 2 * r, y, 2 * r, 2 * r, lw, 0.0f, 90.0f, c);
	pd->graphics->drawEllipse(x + w - 2 * r, y + h - 2 * r, 2 * r, 2 * r, lw, 90.0f, 180.0f, c);
	pd->graphics->drawEllipse(x, y + h - 2 * r, 2 * r, 2 * r, lw, 180.0f, 270.0f, c);
}

static void polarLine(int cx, int cy, float deg, float r0, float r1, int width)
{
	float s = sinf(rad(deg)), c = cosf(rad(deg));
	pd->graphics->drawLine(cx + (int)(s * r0), cy - (int)(c * r0),
		cx + (int)(s * r1), cy - (int)(c * r1), width, kColorBlack);
}

static int dialX(float f)
{
	return SCALE_X0 + (int)((f - DIAL_MIN) / (DIAL_MAX - DIAL_MIN) * (float)(SCALE_X1 - SCALE_X0));
}

// Badge on the grille (skipped by the pulse so it stays readable); sized to its text
#define BADGE_H 38
#define BADGE_CREDIT "your stations"
static int badgeX, badgeY, badgeW;

static void grilleDot(int x, int y, int size)
{
	if (x + 3 >= badgeX && x <= badgeX + badgeW && y + 3 >= badgeY && y <= badgeY + BADGE_H) return;
	pd->graphics->fillRect(x, y, size, size, kColorBlack);
}

// ---- the static cabinet ----

static void buildCabinet(void)
{
	cabinet = pd->graphics->newBitmap(400, 240, kColorWhite);
	pd->graphics->pushContext(cabinet);
	LCDColor black = kColorBlack;

	roundRect(2, 2, 396, 236, 14, 4);

	// dial window and scale
	roundRect(WIN_X, WIN_Y, WIN_W, WIN_H, 6, 3);
	pd->graphics->drawLine(SCALE_X0, SCALE_Y, SCALE_X1, SCALE_Y, 1, black);
	for (int t = 0; t <= 40; t++) {                        // tick every 0.5 MHz
		float f = DIAL_MIN + (float)t * 0.5f;
		int x = dialX(f);
		int major = (t % 4) == 0;                          // number every 2 MHz
		pd->graphics->drawLine(x, SCALE_Y, x, SCALE_Y - (major ? 8 : 3), 1, black);
		if (major) {
			char lbl[8];
			snprintf(lbl, sizeof lbl, "%d", (int)f);
			textCentered(small, lbl, x, SCALE_Y + 4);
		}
	}
	for (int i = 0; i < STATIONS_PER_BAND; i++) {          // station markers
		int x = dialX(kStationFreqs[i]);
		pd->graphics->fillRect(x - 1, SCALE_Y - 15, 3, 4, black);
	}

	// speaker grille and badge
	int bw1 = textWidth(font, "Crank FM"), bw2 = textWidth(small, BADGE_CREDIT);
	badgeW = (bw1 > bw2 ? bw1 : bw2) + 16;
	badgeX = GRILLE_X + (GRILLE_W - badgeW) / 2;
	badgeY = GRILLE_Y + (GRILLE_H - BADGE_H) / 2;
	roundRect(GRILLE_X, GRILLE_Y, GRILLE_W, GRILLE_H, 8, 3);
	for (int y = GRILLE_Y + 7; y < GRILLE_Y + GRILLE_H - 5; y += 5)
		for (int x = GRILLE_X + 7; x < GRILLE_X + GRILLE_W - 5; x += 5)
			grilleDot(x, y, 2);
	pd->graphics->fillRect(badgeX, badgeY, badgeW, BADGE_H, kColorWhite);
	pd->graphics->drawRect(badgeX, badgeY, badgeW, BADGE_H, black);
	pd->graphics->drawRect(badgeX + 2, badgeY + 2, badgeW - 4, BADGE_H - 4, black);
	textCentered(font, "Crank FM", badgeX + badgeW / 2, badgeY + 4);
	textCentered(small, BADGE_CREDIT, badgeX + badgeW / 2, badgeY + 21);

	// label plate, with a rule above the signal/volume line
	pd->graphics->drawRect(PLATE_X, PLATE_Y, PLATE_W, PLATE_H, black);
	pd->graphics->drawRect(PLATE_X + 2, PLATE_Y + 2, PLATE_W - 4, PLATE_H - 4, black);
	pd->graphics->drawLine(PLATE_X + 8, PLATE_Y + 56, PLATE_X + PLATE_W - 9, PLATE_Y + 56, 1, black);
	pd->graphics->setFont(small);
	text("VOL", PLATE_X + PLATE_W - 84, PLATE_Y + 66);

	pd->graphics->popContext();
}

// ---- per-frame drawing ----

static const char* statusWord(void)
{
	if (pd->network->getStatus() == kWifiNotAvailable) return "no wi-fi";
	switch (stream_state()) {
		case STREAM_NEED_ACCESS: return "allow net";
		case STREAM_DENIED:      return "no access";
		case STREAM_CONNECTING:
		case STREAM_BUFFERING:   return stream_rebuffering() ? "buffering" : "tuning";
		case STREAM_PLAYING:     return "live";
		case STREAM_ERROR:       return "no signal";
		default:                 return "static";
	}
}

// Preset keys, one per band; the active one is pressed in (black, no shadow).
static void drawKeys(void)
{
	int w = (KEYS_W - KEY_GAP * (BAND_COUNT - 1)) / BAND_COUNT;
	pd->graphics->setFont(small);
	for (int i = 0; i < BAND_COUNT; i++) {
		int x = KEYS_X + i * (w + KEY_GAP);
		const char* name = kBands[i].name;
		int tx = x + (w - textWidth(small, name)) / 2;
		if (i == band) {
			pd->graphics->fillRect(x, KEYS_Y + 2, w, KEYS_H - 2, kColorBlack);
			pd->graphics->setDrawMode(kDrawModeFillWhite);
			text(name, tx, KEYS_Y + 7);
			pd->graphics->setDrawMode(kDrawModeCopy);
		} else {
			pd->graphics->drawRect(x, KEYS_Y, w, KEYS_H - 2, kColorBlack);
			pd->graphics->fillRect(x + 1, KEYS_Y + KEYS_H - 2, w - 1, 2, kColorBlack);   // key shadow
			text(name, tx, KEYS_Y + 5);
		}
	}
}

static void drawSong(const char* song, float dt, int x, int y, int w)
{
	pd->graphics->setFont(font);
	int tw = textWidth(font, song);
	pd->graphics->setClipRect(x, y, w, 20);
	if (tw <= w) {
		marquee = 0.0f;
		text(song, x, y);
	} else {
		int gap = 40;
		marquee += MARQUEE_SPEED * dt;
		if (marquee >= (float)(tw + gap)) marquee -= (float)(tw + gap);
		text(song, x - (int)marquee, y);
		text(song, x - (int)marquee + tw + gap, y);
	}
	pd->graphics->clearClipRect();
}

static void drawHints(void)
{
	int x = 58, y = 30, w = 284, h = 176;
	pd->graphics->fillRect(x, y, w, h, kColorWhite);
	roundRect(x, y, w, h, 8, 3);
	textCentered(font, "How to tune", x + w / 2, y + 10);
	const char* rows[][2] = {
		{ "Crank", "turn the dial" },
		{ "⬅️ ➡️", "jump to a station" },
		{ "Ⓐ", "fine-tune" },
		{ "Ⓑ", "change band" },
		{ "⬆️ ⬇️", "volume" },
	};
	for (int i = 0; i < 5; i++) {
		pd->graphics->setFont(i == 0 ? font : light);
		text(rows[i][0], x + 24, y + 38 + i * 24);
		pd->graphics->setFont(font);
		text(rows[i][1], x + 108, y + 38 + i * 24);
	}
	textCentered(small, "press any button", x + w / 2, y + h - 18);
}

/**
 * Draws the credits card over the radio: who made the app, who provides the
 * radio streams, and the other things we are built on. Kept as plain centred
 * lines so adding or removing a credit is a one-line change.
 */
static void drawAbout(void)
{
	int x = 40, y = 14, w = 320, h = 212;
	pd->graphics->fillRect(x, y, w, h, kColorWhite);
	roundRect(x, y, w, h, 8, 3);
	int cx = x + w / 2;
	textCentered(font, "Crank FM", cx, y + 12);
	textCentered(small, "created and programmed by", cx, y + 38);
	textCentered(font, "Boraq Abdulmajeed", cx, y + 52);
	textCentered(font, "Nityaansh Parekh", cx, y + 72);
	textCentered(small, "stations", cx, y + 98);
	textCentered(font, "your own", cx, y + 112);
	textCentered(small, "(see stations.h)", cx, y + 130);
	textCentered(small, "built with Claude Code (Anthropic)", cx, y + 150);
	textCentered(small, "mp3 decoding: minimp3 (public domain)", cx, y + 165);
	textCentered(small, "press any button", cx, y + h - 18);
}

static void draw(const Station* near, float dist, float dt)
{
	LCDColor black = kColorBlack;
	const Band* b = &kBands[band];
	pd->graphics->drawBitmap(cabinet, 0, 0, kBitmapUnflipped);

	// dial: station names, lamp glow around the needle, needle
	for (int i = 0; i < STATIONS_PER_BAND; i++)
		textCentered(font, b->stations[i].name, dialX(kStationFreqs[i]), WIN_Y + 5);
	int nx = dialX(freq);
	float glow = stream_state() == STREAM_PLAYING ? quality : 0.0f;
	if (glow > 0.05f) {
		int gw = 4 + (int)(glow * 12.0f);
		pd->graphics->fillRect(nx - gw, WIN_Y + 24, gw * 2 + 1, SCALE_Y - WIN_Y - 26,
			(LCDColor)(glow > 0.6f ? kGlow50 : kGlow25));
	}
	pd->graphics->fillRect(nx - 1, WIN_Y + 4, 3, WIN_H - 8, black);

	// grille pulses with the music: dots near the centre swell
	if (pulse > 1.0f) {
		int cx = GRILLE_X + GRILLE_W / 2, cy = GRILLE_Y + GRILLE_H / 2;
		for (int y = GRILLE_Y + 7; y < GRILLE_Y + GRILLE_H - 5; y += 5)
			for (int x = GRILLE_X + 7; x < GRILLE_X + GRILLE_W - 5; x += 5) {
				float d = sqrtf((float)((x - cx) * (x - cx) + (y - cy) * (y - cy)));
				if (d < pulse) grilleDot(x - 1, y - 1, d > pulse - 6.0f ? 4 : 3);
			}
	}

	// label plate: station + frequency, then the song
	char fbuf[16];
	snprintf(fbuf, sizeof fbuf, "%.1f FM", (double)freq);
	pd->graphics->setFont(small);
	int fw = textWidth(small, fbuf);
	text(fbuf, PLATE_X + PLATE_W - 8 - fw, PLATE_Y + 8);
	pd->graphics->setFont(font);
	pd->graphics->setClipRect(PLATE_X + 8, PLATE_Y + 5, PLATE_W - 24 - fw, 20);
	text(dist < CAPTURE ? near->title : "~ ~ ~", PLATE_X + 8, PLATE_Y + 5);
	pd->graphics->clearClipRect();
	const char* song = stream_state() == STREAM_PLAYING && dist < CAPTURE ? stream_title() : "";
	drawSong(song, dt, PLATE_X + 8, PLATE_Y + 27, PLATE_W - 16);

	// plate footer: signal bars + status, volume
	int bars = (int)(sigLevel * 5.0f + 0.5f);
	for (int i = 0; i < 5; i++) {
		int h = 3 + i * 2, x = PLATE_X + 9 + i * 5, y = PLATE_Y + 78 - h;
		if (i < bars) pd->graphics->fillRect(x, y, 3, h, black);
		else pd->graphics->fillRect(x, PLATE_Y + 77, 3, 1, black);
	}
	pd->graphics->setFont(small);
	text(statusWord(), PLATE_X + 38, PLATE_Y + 66);
	int vx = PLATE_X + PLATE_W - 56, vy = PLATE_Y + 71;
	pd->graphics->drawLine(vx, vy, vx + 46, vy, 1, black);
	pd->graphics->fillRect(vx + (int)(gAudio.volume * 44.0f), vy - 4, 3, 9, black);

	drawKeys();

#if !CLIP_CAPTURE   // (the website clip should not show the docked-crank message the Simulator causes)
	if (pd->system->isCrankDocked() && hintTimer <= 0.0f)
		textCentered(small, "undock the crank to tune", 200, WIN_Y + WIN_H + 1);
#endif
	if (hintTimer > 0.0f) drawHints();
	if (aboutOpen) drawAbout();
}

#if CLIP_CAPTURE
/**
 * Saves 300 consecutive frames (10 seconds at 30fps) as PBM files in the data folder, starting once
 * the station has been playing for 5 seconds so the music and the grille's pulsing are in full swing.
 * Used only to make the website's silent looping clip of the radio.
 */
static void captureFrame(void)
{
	static int playingFrames = 0, saved = 0;
	if (saved >= 300) return;
	if (stream_state() != STREAM_PLAYING) { playingFrames = 0; return; }
	if (++playingFrames < 150) return;
	char name[32];
	snprintf(name, sizeof name, "cap_%04d.pbm", saved++);
	SDFile* f = pd->file->open(name, kFileWrite);
	if (f == NULL) return;
	const char* hdr = "P4\n400 240\n";
	pd->file->write(f, hdr, (unsigned int)strlen(hdr));
	uint8_t* frame = pd->graphics->getFrame();
	uint8_t row[50];
	for (int y = 0; y < 240; y++) {
		for (int i = 0; i < 50; i++) row[i] = (uint8_t)~frame[y * LCD_ROWSIZE + i];   // PBM: 1 = black
		pd->file->write(f, row, 50);
	}
	pd->file->close(f);
	if (saved == 300) dlog("capture done");
}
#endif

#if SCREEN_DUMP
// Writes the frame as a PBM so the screen can be inspected off-device.
static void dumpScreen(void)
{
	static unsigned int next;
	unsigned int now = pd->system->getCurrentTimeMilliseconds();
	if (now < next) return;
	next = now + 3000;
	SDFile* f = pd->file->open("screen.pbm", kFileWrite);
	if (f == NULL) return;
	const char* hdr = "P4\n400 240\n";
	pd->file->write(f, hdr, (unsigned int)strlen(hdr));
	uint8_t* frame = pd->graphics->getFrame();
	uint8_t row[50];
	for (int y = 0; y < 240; y++) {
		for (int i = 0; i < 50; i++) row[i] = (uint8_t)~frame[y * LCD_ROWSIZE + i];   // PBM: 1 = black
		pd->file->write(f, row, 50);
	}
	pd->file->close(f);
}
#endif

static int update(void* userdata)
{
	(void)userdata;
	float dt = clampf(pd->system->getElapsedTime(), 0.001f, 0.1f);
	pd->system->resetElapsedTime();

	static int bootFrames = 3;   // log the phases of the first few frames (device debugging)
	if (bootFrames > 0) dlog("frame %d: start", 3 - bootFrames);
	if (splashTimer <= 0.0f) handleInput(dt);
	else pd->system->getCrankChange();   // discard crank movement during the splash
	float dist;
	const Station* near = &kBands[band].stations[nearestStation(freq, &dist)];
	if (bootFrames > 0) dlog("frame: near %s", near->path);
	manageStream(near, dist);        // the stream starts connecting behind the splash
	if (bootFrames > 0) { dlog("frame: stream ok"); bootFrames--; }
	updateAudioTargets(dist);
	if (splashTimer > 0.0f) {
		// Hold the launch screen; keep the radio silent so it fades in afterwards.
		splashTimer -= dt;
		gAudio.stationGain = 0.0f;
		gAudio.noiseGain = 0.0f;
		if (splash != NULL) pd->graphics->drawBitmap(splash, 0, 0, kBitmapUnflipped);
		else splashTimer = 0.0f;
#if SCREEN_DUMP
		dumpScreen();
#endif
		return 1;
	}
	animate(dt);

	if (hintTimer > 0.0f) {
		hintTimer -= dt;       // (counts only after the splash)
		if (!hintsSeen) { hintsSeen = 1; markDirty(); }
	}
	draw(near, dist, dt);
#if SCREEN_DUMP
	dumpScreen();
#endif
#if CLIP_CAPTURE
	captureFrame();
#endif

	if (dirtySince != 0 && pd->system->getCurrentTimeMilliseconds() - dirtySince >= SAVE_DELAY_MS)
		saveSettings();
	return 1;
}

#ifdef _WINDLL
__declspec(dllexport)
#endif
int eventHandler(PlaydateAPI* playdate, PDSystemEvent event, uint32_t arg)
{
	(void)arg;
	if (event == kEventInit) {
		pd = playdate;
		dlog_init(pd);
		dlog("init: start");
		const char* err = NULL;
		font = pd->graphics->loadFont("/System/Fonts/Asheville-Sans-14-Bold.pft", &err);
		if (font == NULL) pd->system->error("font: %s", err);
		small = pd->graphics->loadFont("/System/Fonts/Roobert-10-Bold.pft", &err);
		if (small == NULL) pd->system->error("font: %s", err);
		light = pd->graphics->loadFont("/System/Fonts/Asheville-Sans-14-Light.pft", &err);
		if (light == NULL) pd->system->error("font: %s", err);
		dlog("init: fonts %p %p %p", (void*)font, (void*)small, (void*)light);
		// 10s of audio: the adaptive buffer (stream.c) can grow to 10s when the Wi-Fi is weak.
		if (!audio_init(pd, 10)) pd->system->error("out of memory for audio buffer");
		setupHeadphones();
		dlog("init: audio");
		loadSettings();
		dlog("init: settings band %d freq %.1f", band, (double)freq);
		if (!aboutSeen) {                    // first launch: credits first, then the controls
			aboutOpen = 1;
			controlsAfterAbout = !hintsSeen;
		} else if (!hintsSeen) hintTimer = HINT_SECONDS;
		buildCabinet();
		dlog("init: cabinet");
		splash = pd->graphics->loadBitmap("launcher/launchImage", &err);
		dlog("init: splash %p", (void*)splash);
		if (splash != NULL) pd->graphics->drawBitmap(splash, 0, 0, kBitmapUnflipped);
		stream_init(pd);
		dlog("init: stream");
		pd->system->addMenuItem("controls", showControls, NULL);
		pd->system->addMenuItem("about", showAbout, NULL);
		pd->display->setRefreshRate(30);
		pd->system->resetElapsedTime();
		pd->system->setUpdateCallback(update, NULL);
		dlog("init: done");
	} else if (event == kEventTerminate || event == kEventLock || event == kEventPause) {
		if (dirtySince != 0) saveSettings();
	}
	return 0;
}
