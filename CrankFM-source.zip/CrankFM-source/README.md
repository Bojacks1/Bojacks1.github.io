# Crank FM: source code

Internet radio for the [Playdate](https://play.date), tuned with the crank like an old tabletop radio: static between stations, and a station that breaks
through muffled and wavering as you come close, then settles in clear. Written in C.

**This copy comes with no stations.** Crank FM was made for SomaFM's channels, and SomaFM does not allow third-party apps to use its streams, so
they are taken out. Add stations whose owners allow it in `src/stations.h` (the file explains what a station needs).

## Build

You need the [Playdate SDK](https://play.date/dev/) (3.x) and `make`.

```sh
make                 # builds CrankFM.pdx for the Simulator and the device
sh build.sh          # builds and opens it in the Playdate Simulator (macOS)
```

## What is where

* `src/main.c`: the app: the dial, the tuning (how close the needle is to a station sets the static, the muffle and the warble), the radio face, settings.
* `src/stream.c`: one http connection at a time, its retries, and a buffer that grows by itself when the Wi-Fi is weak.
* `src/icy.c`: strips the song titles out of the stream (ICY metadata) and reads them.
* `src/decoder.c`: MP3 decoding with [minimp3](https://github.com/lieff/minimp3) (public domain, `src/minimp3.h`).
* `src/audio.c`: the sound: resampling, the static, the muffle, stereo for headphones, a mono mix for the speaker, and a limiter.
* `src/stations.h`: the stations (yours).
* `tools/make_launcher.py`: the launcher pictures. `tools/host_decode_test.c`: a test of the decoder on a Mac.

## Licence

MIT (see `LICENSE`). minimp3 is public domain (CC0). The Beaumont Tower photo in `assets/` is Boraq's own.

Made by Boraq Abdulmajeed and Nityaansh Parekh, with Claude Code. Playdate is a trademark of Panic Inc.
