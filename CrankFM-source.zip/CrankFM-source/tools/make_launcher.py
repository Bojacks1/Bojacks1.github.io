#!/usr/bin/env python3
"""Draw Crank FM's launcher art (1-bit) into Source/launcher/.

Text is rendered with the Playdate system font (Asheville Sans 14 Bold) straight
from the SDK's font table, so it matches the device.

Usage: python3 tools/make_launcher.py [--preview out.png]
"""
import sys
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))   # (pdart.py, the 1-bit art helper, sits beside this script)
from pdart import BLACK, FONT_DIR, WHITE, TableFont, atkinson, system_font  # noqa: E402,F401
PORTRAIT = ROOT / "assets" / "boraq.png"   # cut-out photo (transparent background)
LANDMARK = ROOT / "assets" / "beaumont_tower.png"   # Beaumont Tower (MSU), the launch picture
OUT = ROOT / "Source" / "launcher"


def grille(d, cx, cy, r, step=5, dot=2):
    for y in range(cy - r, cy + r + 1, step):
        for x in range(cx - r, cx + r + 1, step):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                d.rectangle((x, y, x + dot - 1, y + dot - 1), fill=BLACK)


def dial(d, x0, y0, x1, needle_frac, major_every=4, ticks=20):
    d.line((x0, y0, x1, y0), fill=BLACK)
    for t in range(ticks + 1):
        x = x0 + round((x1 - x0) * t / ticks)
        d.line((x, y0, x, y0 - (7 if t % major_every == 0 else 3)), fill=BLACK)
    nx = x0 + round((x1 - x0) * needle_frac)
    d.rectangle((nx - 1, y0 - 14, nx + 1, y0 + 5), fill=BLACK)


def radio_body(d, x0, y0, x1, y1, radius=10):
    d.rounded_rectangle((x0, y0, x1, y1), radius=radius, outline=BLACK, width=3, fill=WHITE)


def card(font):
    img = Image.new("L", (350, 155), WHITE)
    d = ImageDraw.Draw(img)
    x0 = 16                                            # fallback: the drawn radio
    p = hero(151, max_width=148)
    if p is not None:
        img.paste(p, (2, 2))
        d.line((p.width + 2, 2, p.width + 2, 152), fill=BLACK)
        x0 = p.width + 4
    else:
        d.line((40, 24, 22, 6), fill=BLACK, width=2)
        radio_body(d, 16, 24, 150, 132)
        grille(d, 62, 78, 34)
        x0 = 156
    d.rectangle((0, 0, 349, 154), outline=BLACK, width=2)
    # wordmark, dial strip, credit, centred in the space right of the portrait
    cx = x0 + (348 - x0) // 2
    font.draw(img, "Crank FM", cx - font.width("Crank FM", 2) // 2, 28, scale=2)
    dial(d, cx - 78, 104, cx + 78, 0.37)
    credit = "internet radio"
    font.draw(img, credit, cx - font.width(credit) // 2, 118)
    return img


def icon():
    img = Image.new("L", (32, 32), WHITE)
    d = ImageDraw.Draw(img)
    d.line((9, 7, 4, 1), fill=BLACK, width=1)
    d.rounded_rectangle((1, 7, 30, 29), radius=4, outline=BLACK, width=2, fill=WHITE)
    grille(d, 10, 18, 6, step=3, dot=1)
    d.rectangle((19, 12, 27, 16), outline=BLACK)
    d.line((22, 11, 22, 17), fill=BLACK)
    d.ellipse((20, 20, 26, 26), outline=BLACK, width=1)
    return img


def landmark(height, max_width=206):
    """Beaumont Tower, cropped tight around the tower and dithered.

    The crop keeps the tower and a little sky and drops most of the trees: in 1-bit
    the dark foliage turns to black noise and merges with the dark brick, so the
    tower loses its outline. Fractions are of the source photo (x 0.225-0.665)."""
    from PIL import ImageFilter, ImageOps
    src = Image.open(LANDMARK).convert("RGB")
    W, H = src.size
    src = src.crop((int(W * 0.225), 0, int(W * 0.665), H))
    w = round(src.width * height / src.height)
    src = src.resize((w, height), Image.LANCZOS)
    if w > max_width:                                  # leave room for the wordmark
        left = (w - max_width) // 2
        src = src.crop((left, 0, left + max_width, height))
        w = max_width
    gray = ImageOps.autocontrast(src.convert("L"), cutoff=1)
    gray = gray.filter(ImageFilter.UnsharpMask(radius=2, percent=160, threshold=2))
    gray = gray.point(lambda v: int(255 * (v / 255) ** 0.85))   # lift the shadows a little
    return atkinson(gray)


def hero(height, max_width=206):
    """The picture on the launcher art: the landmark, else the portrait, else None."""
    if LANDMARK.exists():
        return landmark(height, max_width)
    if PORTRAIT.exists():
        return portrait(height, max_width)
    return None


def portrait(height, max_width=206):
    """Boraq, head and shoulders, dithered, with a black outline around the cut-out."""
    from PIL import ImageFilter, ImageOps
    src = Image.open(PORTRAIT).convert("RGBA")
    W, H = src.size
    src = src.crop((int(W * 0.38), int(H * 0.10), int(W * 0.86), int(H * 0.52)))
    w = round(src.width * height / src.height)
    src = src.resize((w, height), Image.LANCZOS)
    if w > max_width:                                  # leave room for the wordmark
        src = src.crop((0, 0, max_width, height))
        w = max_width
    alpha = src.getchannel("A").point(lambda a: 255 if a > 128 else 0)
    gray = ImageOps.autocontrast(src.convert("L"), cutoff=1)
    gray = gray.filter(ImageFilter.UnsharpMask(radius=2, percent=160, threshold=2))
    gray = gray.point(lambda v: int(255 * (v / 255) ** 0.85))   # lift the shadows a little
    dith = atkinson(gray)
    outline = alpha.filter(ImageFilter.MaxFilter(3))
    edge = Image.eval(Image.merge("L", [outline]), lambda v: v)
    img = Image.new("L", (w, height), WHITE)
    img.paste(BLACK, (0, 0), edge)                    # 1px black halo around him
    img.paste(dith, (0, 0), alpha)
    return img


def launch_image(font):
    img = Image.new("L", (400, 240), WHITE)
    d = ImageDraw.Draw(img)
    p = hero(240)
    if p is not None:
        img.paste(p, (0, 0))
        x0 = p.width + 4
        cx = x0 + (400 - x0) // 2
        word = "Crank FM"
        font.draw(img, word, cx - font.width(word, 2) // 2, 62, scale=2)
        dial(d, cx - 80, 150, cx + 80, 0.37, ticks=20, major_every=4)
        credit = "internet radio"
        font.draw(img, credit, cx - font.width(credit) // 2, 176)
        return img
    word = "Crank FM"
    font.draw(img, word, (400 - font.width(word, 4)) // 2, 50, scale=4)
    dial(d, 70, 150, 330, 0.37, ticks=40, major_every=4)
    credit = "internet radio"
    font.draw(img, credit, (400 - font.width(credit)) // 2, 180)
    return img


def main():
    font = system_font()
    OUT.mkdir(parents=True, exist_ok=True)
    images = {"card.png": card(font), "icon.png": icon(), "launchImage.png": launch_image(font)}
    for name, img in images.items():
        img.point(lambda v: 255 if v > 127 else 0).convert("1").save(OUT / name)
        print("wrote", (OUT / name).relative_to(ROOT))
    if "--preview" in sys.argv:
        out = sys.argv[sys.argv.index("--preview") + 1]
        sheet = Image.new("L", (420, 420), 200)
        sheet.paste(images["card.png"], (10, 10))
        sheet.paste(images["icon.png"].resize((64, 64), Image.NEAREST), (10, 175))
        sheet.paste(images["icon.png"], (90, 190))
        sheet.paste(images["launchImage.png"].resize((300, 180), Image.NEAREST), (110, 175))
        sheet.resize((840, 840), Image.NEAREST).save(out)
        print("preview:", out)


if __name__ == "__main__":
    main()
