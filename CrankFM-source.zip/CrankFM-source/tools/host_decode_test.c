// Host-side check of decoder.c: feeds an MP3 file in random-sized network-like
// chunks, drains the ring like the audio callback would, and writes a WAV.
//
//   clang -O2 -I src -o /tmp/dectest tools/host_decode_test.c src/decoder.c src/icy.c
//   /tmp/dectest in.mp3 out.wav [icy-metaint]
// With a metaint (e.g. a capture made with `curl -H "Icy-MetaData: 1"`), the ICY
// blocks are stripped by icy.c and each title change is printed.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "decoder.h"
#include "icy.h"

static void* host_alloc(void* p, size_t n) { return realloc(p, n); }

static void put32(FILE* f, uint32_t v) { fwrite(&v, 4, 1, f); }
static void put16(FILE* f, uint16_t v) { fwrite(&v, 2, 1, f); }

int main(int argc, char** argv)
{
	if (argc < 3) { fprintf(stderr, "usage: %s in.mp3 out.wav\n", argv[0]); return 2; }
	FILE* in = fopen(argv[1], "rb");
	FILE* out = fopen(argv[2], "wb");
	if (!in || !out) { perror("open"); return 1; }

	Mp3Stream* s = decoder_new(host_alloc);
	static IcyParser icy;
	icy_init(&icy, argc > 3 ? atoi(argv[3]) : 0);
	int seenTitle = icy.titleVersion;
	PcmRing ring = { malloc(sizeof(int16_t) * 2 * 65536), 65536, 0, 0 };   // stereo frames
	fseek(out, 44, SEEK_SET);

	srand(1);
	long total = 0;
	int frames = 0, eof = 0;
	clock_t t0 = clock();
	while (!eof || ring_count(&ring) > 0) {
		if (!eof) {
			int space;
			uint8_t* dst = decoder_input(s, &space);
			int want = rand() % 3000 + 1;
			if (want > space) want = space;
			size_t n = fread(dst, 1, (size_t)want, in);
			if (n == 0) eof = 1;
			decoder_commit(s, icy_filter(&icy, dst, (int)n));
			if (icy.titleVersion != seenTitle) { seenTitle = icy.titleVersion; printf("title: %s\n", icy.title); }
		}
		int got = decoder_run(s, &ring, 4);
		frames += got;
		if (eof && got == 0 && ring_count(&ring) == 0) break;
		// drain like the audio thread
		uint32_t n = ring_count(&ring);
		for (uint32_t i = 0; i < n; i++) {   // the wav stays mono: average L and R
			int16_t l, r; ring_peek(&ring, i, &l, &r);
			int16_t v = (int16_t)(((int)l + r) >> 1); fwrite(&v, 2, 1, out);
		}
		ring_drop(&ring, n);
		total += n;
	}
	double secs = (double)(clock() - t0) / CLOCKS_PER_SEC;

	int rate = decoder_sample_rate(s);
	fseek(out, 0, SEEK_SET);
	fwrite("RIFF", 1, 4, out); put32(out, (uint32_t)(36 + total * 2));
	fwrite("WAVEfmt ", 1, 8, out); put32(out, 16); put16(out, 1); put16(out, 1);
	put32(out, (uint32_t)rate); put32(out, (uint32_t)rate * 2); put16(out, 2); put16(out, 16);
	fwrite("data", 1, 4, out); put32(out, (uint32_t)(total * 2));
	fclose(out);

	printf("frames=%d samples=%ld rate=%d kbps=%d audio=%.2fs decode=%.3fs\n",
		frames, total, rate, decoder_bitrate(s), rate ? (double)total / rate : 0.0, secs);
	return 0;
}
