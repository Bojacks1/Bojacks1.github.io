"""Shared 1-bit art helpers for the braq Playdate projects (launcher art, sleeves).

- TableFont: draws text with a Playdate .fnt + table PNG, e.g. the system font
  straight from the SDK, so art matches the device.
- atkinson: Atkinson dithering (classic Mac look) for photos and cover art.
"""
from pathlib import Path

from PIL import Image

FONT_DIR = Path.home() / "Developer/PlaydateSDK/Resources/Fonts/Asheville/Asheville Sans 14 Bold"
BLACK, WHITE = 0, 255


def system_font():
    """Asheville Sans 14 Bold, the Playdate's bold system font."""
    return TableFont(FONT_DIR / "Asheville-Sans-14-Bold.fnt",
                     FONT_DIR / "Asheville-Sans-14-Bold-table-20-20.png")


class TableFont:
    """Playdate .fnt + -table-W-H.png: glyph i is cell i of the grid, in file order."""

    def __init__(self, fnt, table, cell=20):
        self.cell = cell
        self.sheet = Image.open(table).convert("RGBA")
        self.cols = self.sheet.width // cell
        self.glyphs, self.tracking = {}, 0
        index = 0
        for line in fnt.read_text(encoding="utf-8").splitlines():
            if line.startswith("tracking="):
                self.tracking = int(line.split("=")[1])
                continue
            parts = [p for p in line.split("\t") if p]
            if len(parts) != 2:
                continue
            ch = " " if parts[0] == "space" else parts[0]
            self.glyphs[ch] = (index, int(parts[1]))
            index += 1

    def width(self, text, scale=1):
        w = sum(self.glyphs[c][1] for c in text) + self.tracking * (len(text) - 1)
        return w * scale

    def draw(self, img, text, x, y, scale=1, fill=BLACK):
        for c in text:
            i, w = self.glyphs[c]
            cx, cy = (i % self.cols) * self.cell, (i // self.cols) * self.cell
            glyph = self.sheet.crop((cx, cy, cx + self.cell, cy + self.cell))
            mask = glyph.getchannel("A").point(lambda a: 255 if a > 127 else 0)
            # glyph pixels are the opaque *black* ones
            ink = Image.eval(glyph.convert("L"), lambda v: 255 if v < 128 else 0)
            mask = Image.composite(mask, Image.new("L", mask.size, 0), ink)
            if scale != 1:
                mask = mask.resize((self.cell * scale, self.cell * scale), Image.NEAREST)
            img.paste(fill, (x, y), mask)
            x += (w + self.tracking) * scale


def atkinson(gray):
    """Atkinson dither (classic Mac look): L image -> list of rows of 0/255."""
    w, h = gray.size
    px = [list(gray.crop((0, y, w, y + 1)).getdata()) for y in range(h)]
    px = [[float(v) for v in row] for row in px]
    for y in range(h):
        for x in range(w):
            old = px[y][x]
            new = 255.0 if old > 127 else 0.0
            err = (old - new) / 8.0
            px[y][x] = new
            for dx, dy in ((1, 0), (2, 0), (-1, 1), (0, 1), (1, 1), (0, 2)):
                if 0 <= x + dx < w and y + dy < h:
                    px[y + dy][x + dx] += err
    out = Image.new("L", (w, h))
    out.putdata([int(v) for row in px for v in row])
    return out
