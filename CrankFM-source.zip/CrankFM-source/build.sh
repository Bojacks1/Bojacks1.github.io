#!/bin/sh
# Build CrankFM.pdx (Simulator + device) and run it in the Playdate Simulator.
# Pass --no-run to only build. `make clean` for a fresh build.
# Regenerate launcher art with: python3 tools/make_launcher.py
set -e
cd "$(dirname "$0")"
make
[ "$1" = "--no-run" ] && exit 0

# Launch the Simulator binary directly. Opening it via `open -a` (LaunchServices)
# leaves networking broken: every http get() fails with -1 (NET_NO_DEVICE).
# (Bare `open CrankFM.pdx` is worse: .pdx can be claimed by Adobe Acrobat.)
SIM="$HOME/Developer/PlaydateSDK/bin/Playdate Simulator.app/Contents/MacOS/Playdate Simulator"
osascript -e 'quit app "Playdate Simulator"' >/dev/null 2>&1 || true
sleep 1
nohup "$SIM" "$PWD/CrankFM.pdx" >/dev/null 2>&1 &
sleep 3
osascript -e 'tell application "Playdate Simulator" to activate' >/dev/null 2>&1 || true
