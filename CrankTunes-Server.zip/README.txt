Crank Tunes music server
========================
This small program runs on your Mac or Linux computer and serves your own songs to the Crank Tunes app on a Playdate.
It also shows what is playing in Spotify or other music apps on that computer, and lets the Playdate control them.

Needs: python3. For best results also ffmpeg (shrinks songs), Pillow (album covers) and, on Linux, playerctl.
Try it by hand:   python3 crank_server.py --music ~/Music --port 8000 --kbps 96 --key choose-a-secret
Linux, always on: bash install.sh ~/Music 8000   (read LINUX_SERVER.md first)
On the Playdate, server.txt (in the Data folder ending in com.braq.tunes) holds one line:   ADDRESS:8000 choose-a-secret
Only play music you own or have the right to use. Made by Boraq Abdulmajeed.
