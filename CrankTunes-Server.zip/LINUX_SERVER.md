# Crank Tunes music server on Linux

This sets up a Linux computer (a laptop, a Raspberry Pi, a mini PC) as the music host for Crank Tunes on your Playdate.
It does two things:

1. **Library mode:** streams the songs in a folder, shrunk to 96 kbps so the Playdate's Wi-Fi keeps up.
2. **Remote mode:** shows and controls whatever is playing on that computer (Spotify, VLC, Firefox, any player that
   supports MPRIS) through `playerctl`.

On a Mac, use the Playdate Library app instead: it has this server built in.

## Set it up (Debian, Ubuntu, Mint)

1. Unzip `CrankTunes-Server.zip`, for example into your Downloads folder. Keep the files together.
2. Open a terminal in that folder and run the installer. `~/Music` is where your songs are; `8000` is the port.

   ```sh
   cd ~/Downloads/CrankTunes-Server
   bash install.sh ~/Music 8000
   ```

   It may ask for your password once, to install the helpers (ffmpeg, Pillow, playerctl). Then it copies the server
   into your home folder, makes a secret key, and starts a service that runs by itself and starts again after a reboot.
   At the end it prints one line, for example:

   ```
   192.168.1.40:8000 Xk3p9Qm2LwTn7VbR4ysJ6HdA
   ```

   The first part is this computer's address; the second is the key.
3. Put songs (MP3, M4A, FLAC...) in the music folder. New songs show up the next time the Playdate loads its list.

You can delete the unzipped folder afterwards; the installer copied what it needs.

## Tell the Playdate where the server is

1. On the Playdate: Settings, System, Reboot to Data Disk. Connect it to a computer with a USB cable.
2. Open the `Data` folder, then the folder whose name ends in `com.braq.tunes`.
   (It is `user.<number>.com.braq.tunes` if you installed Crank Tunes from play.date/account/sideload.)
   The folder appears after you have opened Crank Tunes once.
3. Make a plain text file called `server.txt` there, holding just the line the installer printed.
4. Eject the Playdate, keep it on the same Wi-Fi as the computer, and open Crank Tunes.

## Check on it

```sh
systemctl --user status crank-tunes        # is it running?
journalctl --user -u crank-tunes -f        # live log: shows each song the Playdate asks for
cat ~/.config/crank-tunes/env              # shows the key again
hostname -I                                # shows the address again (the first number)
```

The address can change when the computer joins a different network. If the Playdate cannot connect, check it again.

## Other distros

The installer only installs helpers on Debian-style systems. Elsewhere, install them yourself, then run `bash install.sh`:

| Fedora | Arch |
|---|---|
| `sudo dnf install python3 python3-pillow ffmpeg playerctl` | `sudo pacman -S python python-pillow ffmpeg playerctl` |

To try the server by hand without installing it:
`python3 crank_server.py --music ~/Music --port 8000 --kbps 96 --key choose-a-secret`
(then `server.txt` holds `ADDRESS:8000 choose-a-secret`).
Without ffmpeg the server still works but sends MP3 files as they are (fine for small MP3s; M4A and FLAC need ffmpeg).

## The key

The key stops other people on the same network from browsing your library or controlling your music. It is stored in
`~/.config/crank-tunes/env`, readable only by you. Too many wrong keys from one address locks that address out for a minute.
It travels as plain text over plain `http`, so on a home network it keeps out casual visitors but is not hidden from
someone who can watch your Wi-Fi traffic.

## Away from home

The Playdate cannot use Tailscale or other VPNs. To reach the server from another network, a Cloudflare Tunnel works:
install `cloudflared`, run `cloudflared tunnel --url http://localhost:8000` (it prints a `https://...trycloudflare.com`
address), and put that address and the key in `server.txt`:

```
https://something.trycloudflare.com Xk3p9Qm2LwTn7VbR4ysJ6HdA
```

The connection is then encrypted. Keep the key on, because that address is public. A permanent name needs a free Cloudflare
account and your own domain. This route has not been tested with a real Playdate yet.

The Playdate's Wi-Fi manages about 18 KB/s and a 96 kbps song needs 12 KB/s, so it works with little to spare; a tunnel
can add stalls (the app enlarges its buffer by itself when that happens).

## Laptop tips

- Closing the lid suspends the laptop and stops the server. To keep it running with the lid shut, set
  `HandleLidSwitch=ignore` in `/etc/systemd/logind.conf`, then run `sudo systemctl restart systemd-logind`.
- Keep it plugged in: shrinking a song keeps a processor core busy for a few seconds the first time it plays (the
  result is kept, so later plays are instant).
- Remote mode controls the music app of the user the service runs as, so stay logged in to that user's desktop.

## Tested

The installer and server ran on Ubuntu 26.04 (Python 3.14): the service starts and restarts itself, a request without
the key is refused, song lengths, shrinking and live song-list updates work, and the Playdate Simulator played from it. Not yet tried: a real Playdate playing from a Linux server, Fedora or Arch, a Cloudflare
Tunnel, and remote mode with a real player on Linux.
