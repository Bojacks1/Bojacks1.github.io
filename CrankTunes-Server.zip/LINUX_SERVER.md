# Running the Crank Tunes server on Linux

The Mac app is not needed. Any Linux machine (your Dell laptop, a Raspberry Pi, a mini PC) can be the music host.
It does two jobs for the Playdate:

1. **Library mode:** streams the songs in a folder, re-encoded small (96 kbps) so the Playdate's Wi-Fi keeps up.
2. **Remote mode:** shows and controls whatever is playing on that machine (Spotify, VLC, Firefox, anything that
   speaks MPRIS) through `playerctl`.

## Quick start (Debian, Ubuntu, Mint)

```sh
cd tunes/linux
./install.sh ~/Music 8000
```

It installs the helpers, copies the server, makes a secret key, starts a systemd user service that restarts itself,
and prints the line for the Playdate. Put that line in `Data/com.braq.tunes/server.txt` (Data Disk mode), for example:

```
192.168.1.40:8000 Xk3p9Qm2LwTn7VbR4ysJ6HdA
```

The first word is the address; the second is the key. Songs go in the music folder. Check the service any time:

```sh
systemctl --user status crank-tunes
journalctl --user -u crank-tunes -f      # live log: shows each song the Playdate asks for
```

## Other distros

| | Debian/Ubuntu | Fedora | Arch |
|---|---|---|---|
| helpers | `apt install python3 python3-pil ffmpeg playerctl` | `dnf install python3 python3-pillow ffmpeg playerctl` | `pacman -S python python-pillow ffmpeg playerctl` |

Then copy `server/crank_server.py` somewhere, and run it by hand to try it:
`CRANK_KEY=secret python3 crank_server.py --music ~/Music --port 8000 --kbps 96`.
Without ffmpeg the server still works but streams the original MP3 files (fine for small MP3s; M4A and FLAC need ffmpeg).

## The key

The key stops other people on the same network from listening to your library. It is stored in
`~/.config/crank-tunes/env` (only you can read it). Too many wrong keys from one address locks that address out for a minute.
The key is sent as plain text over plain `http`, so on a home network it keeps out casual visitors but is not secret
from someone who can watch your Wi-Fi. For use away from home, use one of the two options below, which encrypt it.

## Reaching it away from home

Pick ONE. Both keep the server closed to the open internet (no router changes).

- **Tailscale (good for your Mac, phone and laptop, but NOT for the Playdate):** the Playdate cannot run Tailscale,
  so it cannot reach a Tailscale-only address. Use Tailscale to manage the Linux machine from afar, and use the
  next option for the Playdate itself.
- **Cloudflare Tunnel:** gives the server a public `https://` name that only forwards to your machine. Install
  `cloudflared`, run `cloudflared tunnel --url http://localhost:8000` to try it (it prints a `https://….trycloudflare.com`
  address), then put that in the Playdate's `server.txt`:
  ```
  https://something.trycloudflare.com Xk3p9Qm2LwTn7VbR4ysJ6HdA
  ```
  The Playdate then talks encrypted HTTPS, so the key cannot be read on the way. Keep the key on: the address is public.
  For a permanent name you need a free Cloudflare account and your own domain.

Speed: the Playdate's Wi-Fi gives about 18 KB/s (measured). A 96 kbps song needs 12 KB/s, so it works but with little to spare;
over a tunnel the extra distance can add stalls (the app enlarges its buffer by itself when that happens).

## Laptop tips (Dell)

- Closing the lid suspends the laptop and stops the server. Set `HandleLidSwitch=ignore` in `/etc/systemd/logind.conf`
  (then `sudo systemctl restart systemd-logind`) to keep it running with the lid shut.
- Plug it in; streaming plus re-encoding keeps a CPU core busy for a few seconds per song (the first play of each song;
  the result is cached).
- The remote mode controls the music app of the user the service runs as, so log in to that user's desktop session.

## What was tested

On 2026-10-27 the installer and server ran on a real Ubuntu 26.04 laptop (Python 3.14): the 10 server tests pass, the
service starts and restarts itself, a request without the key gets 403, song lengths (through `ffprobe`), 96 kbps
re-encoding and live song-list updates work. Not yet tried: a real Playdate playing from it, Fedora or Arch,
a Cloudflare Tunnel, and the remote mode with a real player (Spotify, VLC). The Crank Chat relay is separate (see `texting/`).
