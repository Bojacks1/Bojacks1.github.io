#!/usr/bin/env bash
# install.sh: sets up the Crank Tunes music server on a Linux machine (tested on Ubuntu; the helpers are
# installed automatically on Debian/Ubuntu/Mint, and the commands for other distros are in LINUX_SERVER.md). It runs as YOUR user, not root, except for the
# one `apt install` line, which asks for your password.
#
#   bash install.sh                 music in ~/Music, port 8000
#   bash install.sh ~/Songs 9000    music in ~/Songs, port 9000
#
# What it does, step by step (so you can see there is no magic):
#   1. installs the helpers the server uses: python3, ffmpeg (re-encodes songs small), python3-pil (album covers),
#      playerctl (lets the Playdate remote-control Spotify/VLC/etc. on this machine)
#   2. copies crank_server.py to ~/.local/share/crank-tunes/
#   3. makes a secret key (once) in ~/.config/crank-tunes/env, which the Playdate must send
#   4. installs a systemd USER service that starts at boot and restarts if it crashes
#   5. prints the lines to put in the Playdate's server.txt
set -euo pipefail

MUSIC="${1:-$HOME/Music}"
PORT="${2:-8000}"
HERE="$(cd "$(dirname "$0")" && pwd)"
# the server sits beside this script in the download (a flat zip) and in ../server in the project
SERVER_SRC="$HERE/crank_server.py"
[ -f "$SERVER_SRC" ] || SERVER_SRC="$HERE/../server/crank_server.py"
APP_DIR="$HOME/.local/share/crank-tunes"
CONF_DIR="$HOME/.config/crank-tunes"
UNIT_DIR="$HOME/.config/systemd/user"

if [ ! -f "$SERVER_SRC" ]; then
	echo "Cannot find $SERVER_SRC. Keep this script next to crank_server.py." >&2
	exit 1
fi

# 1. helpers (Debian/Ubuntu family; on Fedora use dnf, on Arch use pacman: see the doc). Only asks for your
#    password when something is missing, so a second run (or a run over SSH after you installed them) needs none.
MISSING=""
command -v ffmpeg >/dev/null 2>&1 || MISSING="$MISSING ffmpeg"
command -v playerctl >/dev/null 2>&1 || MISSING="$MISSING playerctl"
python3 -c 'import PIL' >/dev/null 2>&1 || MISSING="$MISSING python3-pil"
if [ -n "$MISSING" ]; then
	if command -v apt-get >/dev/null 2>&1; then
		echo "Installing helpers:$MISSING (asks for your password)..."
		sudo apt-get install -y python3$MISSING
	else
		echo "Missing:$MISSING. Install them yourself (see LINUX_SERVER.md)."
	fi
fi

# 2. the server program
mkdir -p "$APP_DIR" "$CONF_DIR" "$UNIT_DIR" "$MUSIC"
cp "$SERVER_SRC" "$APP_DIR/crank_server.py"
cp "$(dirname "$SERVER_SRC")/arabic_text.py" "$APP_DIR/arabic_text.py"   # shapes Arabic titles for the Playdate; the server imports it

# 3. the key: made once, then kept. 24 random letters and digits.
if [ ! -f "$CONF_DIR/env" ]; then
	KEY="$(python3 -c 'import secrets,string; print("".join(secrets.choice(string.ascii_letters+string.digits) for _ in range(24)))')"
	umask 077                      # only you can read the file
	printf 'CRANK_KEY=%s\n' "$KEY" > "$CONF_DIR/env"
	echo "Made a new key."
fi
KEY="$(sed -n 's/^CRANK_KEY=//p' "$CONF_DIR/env")"

# 4. the service. %h is "your home folder" for systemd. The key comes from the env file, not the command line,
#    so it does not show up in `ps`.
cat > "$UNIT_DIR/crank-tunes.service" <<EOF
[Unit]
Description=Crank Tunes music server for the Playdate
After=network-online.target
Wants=network-online.target

[Service]
EnvironmentFile=%h/.config/crank-tunes/env
ExecStart=/usr/bin/python3 %h/.local/share/crank-tunes/crank_server.py --music "$MUSIC" --port $PORT --kbps 96 --bind 0.0.0.0
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
EOF

systemctl --user daemon-reload
systemctl --user enable --now crank-tunes.service
# lets the service run at boot without you logging in (needs your password once)
loginctl enable-linger "$USER" 2>/dev/null || sudo loginctl enable-linger "$USER" || true

IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo
echo "Done. The server is running. Check it with:  systemctl --user status crank-tunes"
echo
echo "On the Playdate (Data Disk mode), put this one line in server.txt, in the Data folder whose name ends in com.braq.tunes:"
echo "    ${IP:-ADDRESS-OF-THIS-MACHINE}:$PORT $KEY"
echo "(Use it on the same Wi-Fi. To reach it away from home, see LINUX_SERVER.md: use a Cloudflare Tunnel, because the Playdate cannot use Tailscale.)"
echo "Put songs (MP3, M4A, FLAC...) in $MUSIC and the server finds them the next time the Playdate loads its song list."
